"""Phase-1B disposable no-provider capability probe harness.

This module backs the explicitly gated ``claude-multi-dev probe`` command
used by the G1 capability probes (blueprint §12, plan §§5.1–5.5). It builds
a fully disposable fixture — private HOME/XDG/config/state/cache/runtime
directories, disjoint daemon/socket/lock paths, zero provider tokens — and a
deterministic loopback-only fake Anthropic endpoint, so the pinned Claude
binary can later be exercised without any real provider, credential, user
transcript, or contact with the live shared daemon.

Fail-closed refusals:

- missing ``--allow-local-claude`` or ``--fixture-root``
  (``--allow-local-claude`` is presence-based explicit consent: its value
  is ignored and it never relaxes any other check);
- fixture roots that are relative, contain ``..``, resolve through a
  symlink (leaf or any ancestor), are not owner-private, or that equal,
  contain, or enter the live HOME, XDG, ``CLAUDE_CONFIG_DIR``, Claude
  config, claude-multi state, or uid-shared daemon paths (live roots are
  canonicalized before comparison, so symlinked environment roots cannot
  hide an overlap);
- inherited provider credentials in the ambient environment;
- non-loopback or non-http provider endpoints (only the ``127.0.0.1``
  literal is accepted; IPv6 is rejected consistently rather than bound);
- native execution whose trusted executable spec does not pin the exact
  absolute non-symlink path and full SHA-256 of the artifact, or whose
  artifact is group/other-writable.

Daemon-isolation posture (P0): the fixture's daemon/socket/lock paths are
disjoint storage for the harness's own artifacts only. They do NOT redirect
Claude's uid-keyed ``/tmp/cc-daemon-<uid>`` daemon domain, and no claim is
made that the pinned binary honors any environment redirection without
probe evidence. Real native execution runs only inside the P0 namespace
mechanism (``claude_multi.p0``) with the separate explicit
``--allow-real-execution`` flag; outside P0, real native execution fails
closed with a P0-isolation-not-proven refusal and only fake-executable unit
probes (trusted spec marked ``fake=True``) run.

The probed process never inherits the ambient environment: it receives only
the constructed disposable variables plus a fixed non-secret dummy token.
Captured request evidence is metadata only (method, path, model, tool
names, auth classification, body SHA-256); prompt and transcript content is
never persisted to disk or evidence.

Residual: the lstat/hash-to-exec window cannot be fully closed without
exec-time fd-based verification; a same-uid attacker replacing the pinned
artifact between hashing and exec is a recorded, accepted residual for this
probe harness.
"""

from __future__ import annotations

import hashlib
import os
import re
import signal
import stat
import subprocess
import sys
import threading
import urllib.parse
from collections.abc import Mapping
from dataclasses import asdict, dataclass
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from pathlib import Path
from typing import Any, Callable

from . import state, strict_json


class ProbeError(RuntimeError):
    """Raised on any probe safety violation (fail closed)."""


DUMMY_TOKEN = "claude-multi-probe-dummy-token"

_LOOPBACK_HOSTS = ("127.0.0.1",)
_SHA256_RE = re.compile(r"[0-9a-f]{64}")
_MAX_BODY_BYTES = 1024 * 1024
_RECORD_CAP = 1024
_P0_REFUSAL = (
    "refusing real native execution outside P0: the pinned Claude binary "
    "shares the uid-keyed /tmp/cc-daemon-<uid> daemon domain, which this "
    "harness does not redirect. Run the real binary via the P0 namespace "
    "mechanism (--p0 with the separate explicit --allow-real-execution "
    "flag); outside P0 only fake-executable unit probes (trusted spec "
    "marked fake=True) run."
)
_PROVIDER_PREFIXES = (
    "ANTHROPIC",
    "CLAUDE",
    "OPENAI",
    "GEMINI",
    "GOOGLE",
    "MISTRAL",
    "COHERE",
    "MOONSHOT",
    "KIMI",
    "DEEPSEEK",
    "AWS",
    "AZURE",
    "GROQ",
    "XAI",
    "HF",
    "HUGGINGFACE",
    "OPENROUTER",
    "TOGETHER",
    "FIREWORKS",
    "PERPLEXITY",
    "LITELLM",
    "HELICONE",
    "PORTKEY",
)
_CREDENTIAL_MARKERS = ("KEY", "TOKEN", "SECRET", "PASS")


# ------------------------------------------------------------- credentials


def assert_no_provider_credentials(environ: Mapping[str, str]) -> None:
    """Refuse an ambient environment carrying provider credentials.

    Offending variable names are reported; values are never read into
    messages or evidence.
    """

    offenders = sorted(
        name
        for name, value in environ.items()
        if value
        and any(marker in name.upper() for marker in _CREDENTIAL_MARKERS)
        and name.upper().startswith(_PROVIDER_PREFIXES)
    )
    if offenders:
        raise ProbeError(
            "inherited provider credentials are forbidden in the probe "
            "environment; unset them first: " + ", ".join(offenders)
        )


# ------------------------------------------------------------ path safety


def _is_within(path: Path, root: Path) -> bool:
    try:
        path.relative_to(root)
        return True
    except ValueError:
        return False


def _live_roots(environ: Mapping[str, str]) -> dict[str, Path]:
    """Live paths a fixture root must never equal, contain, or enter.

    Ordered most-specific first so containment refusals name the tightest
    live domain; equality is checked in a separate first pass.
    """

    home = Path(environ.get("HOME") or Path.home())
    state_home = Path(environ.get("XDG_STATE_HOME") or home / ".local" / "state")
    roots = {
        "Claude config root": home / ".claude",
        "claude-multi state root": state_home / "claude-multi",
        "uid-shared daemon socket": Path(f"/tmp/cc-daemon-{os.geteuid()}"),
        "XDG_CONFIG_HOME": Path(environ.get("XDG_CONFIG_HOME") or home / ".config"),
        "XDG_STATE_HOME": state_home,
        "XDG_CACHE_HOME": Path(environ.get("XDG_CACHE_HOME") or home / ".cache"),
        "XDG_DATA_HOME": Path(
            environ.get("XDG_DATA_HOME") or home / ".local" / "share"
        ),
        "HOME": home,
    }
    runtime = environ.get("XDG_RUNTIME_DIR")
    if runtime:
        roots["XDG_RUNTIME_DIR"] = Path(runtime)
    claude_dir = environ.get("CLAUDE_CONFIG_DIR")
    if claude_dir:
        roots["CLAUDE_CONFIG_DIR"] = Path(claude_dir)
    return roots


def _resolve_fixture_root(root: Path | str) -> Path:
    candidate = Path(root)
    if not candidate.is_absolute():
        raise ProbeError(f"fixture root {candidate} must be an absolute path")
    if ".." in candidate.parts:
        raise ProbeError(f"fixture root {candidate} must not contain '..'")
    real = Path(os.path.realpath(candidate))
    if real != candidate:
        raise ProbeError(
            f"fixture root {candidate} resolves through a symlink or non-normal "
            f"component to {real}; only real private paths are allowed"
        )
    return real


def _check_live_roots(root: Path, environ: Mapping[str, str]) -> None:
    # Canonicalize every live root: an environment root that passes through
    # a symlink must still refuse a fixture overlapping its real target.
    live_roots = {
        label: Path(os.path.realpath(live))
        for label, live in _live_roots(environ).items()
    }
    for label, live in live_roots.items():
        if root == live:
            raise ProbeError(f"fixture root {root} is the live {label} path")
    for label, live in live_roots.items():
        if _is_within(live, root):
            raise ProbeError(
                f"fixture root {root} contains the live {label} path {live}"
            )
        # Disposable trees under HOME itself are fine; nesting inside a live
        # config/state/daemon tree is never fine.
        if label != "HOME" and _is_within(root, live):
            raise ProbeError(
                f"fixture root {root} is inside the live {label} path {live}"
            )


def _ensure_private(path: Path, what: str) -> Path:
    try:
        return state.ensure_private_dir(path)
    except (state.StateError, OSError) as exc:
        raise ProbeError(
            f"{what} {path} is not a safe private directory: {exc}"
        ) from exc


# --------------------------------------------------------------- endpoints


def check_loopback_url(base_url: str) -> str:
    """Require an explicit http loopback URL with an explicit port."""

    parts = urllib.parse.urlsplit(base_url)
    if parts.scheme != "http":
        raise ProbeError(f"provider endpoint {base_url!r} is not loopback http")
    if parts.hostname not in _LOOPBACK_HOSTS:
        raise ProbeError(f"provider endpoint {base_url!r} is not loopback http")
    try:
        port = parts.port
    except ValueError as exc:
        raise ProbeError(
            f"provider endpoint {base_url!r} has an invalid port"
        ) from exc
    if port is None:
        raise ProbeError(f"provider endpoint {base_url!r} requires an explicit port")
    return base_url


# ----------------------------------------------------------------- fixture


@dataclass(frozen=True)
class ProbeFixture:
    """Disposable probe filesystem domain; every path lives under ``root``."""

    root: Path
    home: Path
    xdg_config_home: Path
    xdg_state_home: Path
    xdg_cache_home: Path
    xdg_data_home: Path
    xdg_runtime_dir: Path
    claude_config_dir: Path
    daemon_dir: Path
    socket_path: Path
    lock_path: Path

    def environ(self, *, base_url: str | None = None) -> dict[str, str]:
        """Disposable process environment; never derived from os.environ.

        With ``base_url`` the loopback fake provider is wired in using the
        fixed non-secret dummy token; without it no provider variable
        exists at all.
        """

        env = {
            "HOME": str(self.home),
            "XDG_CONFIG_HOME": str(self.xdg_config_home),
            "XDG_STATE_HOME": str(self.xdg_state_home),
            "XDG_CACHE_HOME": str(self.xdg_cache_home),
            "XDG_DATA_HOME": str(self.xdg_data_home),
            "XDG_RUNTIME_DIR": str(self.xdg_runtime_dir),
            "CLAUDE_CONFIG_DIR": str(self.claude_config_dir),
            # Explicit minimal PATH: no empty entry, never the ambient PATH.
            "PATH": "/usr/bin:/bin",
            "TERM": "xterm-256color",
            "LANG": "C.UTF-8",
            "DISABLE_AUTOUPDATER": "1",
        }
        if base_url is not None:
            env["ANTHROPIC_BASE_URL"] = check_loopback_url(base_url)
            env["ANTHROPIC_AUTH_TOKEN"] = DUMMY_TOKEN
        return env


def _assert_daemon_disjoint(fixture: ProbeFixture) -> None:
    """Probe daemon/socket/lock paths must never touch the live uid domain."""

    live = Path(f"/tmp/cc-daemon-{os.geteuid()}")
    for path in (fixture.daemon_dir, fixture.socket_path, fixture.lock_path):
        real = Path(os.path.realpath(path))
        if real == live or _is_within(real, live):
            raise ProbeError(
                f"probe daemon path {real} overlaps the live uid-shared daemon "
                f"socket directory {live}"
            )
        if not _is_within(real, fixture.root):
            raise ProbeError(
                f"probe daemon path {real} escapes the fixture root {fixture.root}"
            )


def build_fixture(
    root: Path | str, *, environ: Mapping[str, str] | None = None
) -> ProbeFixture:
    """Create and validate the disposable fixture domain (fail closed).

    An existing fixture is revalidated and reused; every directory must be
    owner-controlled mode 0700 and no path may be a symlink.
    """

    ambient = os.environ if environ is None else environ
    resolved = _resolve_fixture_root(root)
    _check_live_roots(resolved, ambient)
    _ensure_private(resolved, "fixture root")
    home = _ensure_private(resolved / "home", "disposable HOME")
    xdg = _ensure_private(resolved / "xdg", "disposable XDG root")
    runtime = _ensure_private(resolved / "runtime", "disposable runtime root")
    fixture = ProbeFixture(
        root=resolved,
        home=home,
        xdg_config_home=_ensure_private(xdg / "config", "disposable XDG config"),
        xdg_state_home=_ensure_private(xdg / "state", "disposable XDG state"),
        xdg_cache_home=_ensure_private(xdg / "cache", "disposable XDG cache"),
        xdg_data_home=_ensure_private(xdg / "data", "disposable XDG data"),
        xdg_runtime_dir=runtime,
        claude_config_dir=_ensure_private(
            resolved / "claude-config", "disposable Claude config root"
        ),
        daemon_dir=_ensure_private(runtime / "daemon", "disposable daemon root"),
        socket_path=runtime / "daemon" / "control.sock",
        lock_path=runtime / "probe.lock",
    )
    _assert_daemon_disjoint(fixture)
    return fixture


def fixture_manifest(fixture: ProbeFixture) -> dict[str, Any]:
    """Machine-readable fixture summary: paths only, never tokens."""

    return {
        "version": 1,
        "root": str(fixture.root),
        "dirs": {
            "home": str(fixture.home),
            "xdg_config_home": str(fixture.xdg_config_home),
            "xdg_state_home": str(fixture.xdg_state_home),
            "xdg_cache_home": str(fixture.xdg_cache_home),
            "xdg_data_home": str(fixture.xdg_data_home),
            "xdg_runtime_dir": str(fixture.xdg_runtime_dir),
            "claude_config_dir": str(fixture.claude_config_dir),
        },
        "daemon": {
            "dir": str(fixture.daemon_dir),
            "socket": str(fixture.socket_path),
            "lock": str(fixture.lock_path),
        },
    }


def write_evidence(
    fixture: ProbeFixture, name: str, record: dict[str, Any]
) -> Path:
    """Persist a machine-readable probe artifact inside the private fixture."""

    evidence_dir = state.ensure_private_dir(fixture.root / "evidence")
    path = evidence_dir / f"{state.check_name(name)}.json"
    state.atomic_write(path, strict_json.canonical_file_bytes(record))
    return path


# ------------------------------------------------------------ fake provider


@dataclass(frozen=True)
class RequestRecord:
    """Captured request metadata; prompt/transcript content is never stored."""

    method: str
    path: str
    model: str | None
    tool_names: tuple[str, ...]
    has_system: bool
    auth: str  # "dummy" | "other" | "absent"
    body_sha256: str


def _default_responder(document: dict[str, Any]) -> tuple[int, dict[str, Any]]:
    """Deterministic canned Anthropic-shaped reply.

    Echoes the requested model; emits a fixed ``tool_use`` block for the
    first (or forced) tool only when the client supplies tools with an
    ``any``/``tool`` tool_choice, else a fixed text block. This keeps
    registry/deny tool-use probes deterministic: the fake only ever echoes
    what the client actually sent.
    """

    model = document.get("model")
    tools = document.get("tools") or []
    tool_names = [
        tool["name"]
        for tool in tools
        if isinstance(tool, dict) and isinstance(tool.get("name"), str)
    ]
    tool_choice = document.get("tool_choice")
    if tool_names and isinstance(tool_choice, dict) and tool_choice.get("type") in (
        "any",
        "tool",
    ):
        forced = tool_choice.get("name")
        name = forced if forced in tool_names else tool_names[0]
        content = [
            {"type": "tool_use", "id": "toolu_probe_0001", "name": name, "input": {}}
        ]
        stop_reason = "tool_use"
    else:
        content = [{"type": "text", "text": "PROBE-OK"}]
        stop_reason = "end_turn"
    return 200, {
        "id": "msg_probe_0001",
        "type": "message",
        "role": "assistant",
        "content": content,
        "model": model if isinstance(model, str) else "probe-model",
        "stop_reason": stop_reason,
        "stop_sequence": None,
        "usage": {"input_tokens": 1, "output_tokens": 1},
    }


class _ProviderHandler(BaseHTTPRequestHandler):
    server_version = "claude-multi-probe/1"
    protocol_version = "HTTP/1.1"

    def log_message(self, *_args: Any) -> None:
        return

    def _send_json(self, status: int, payload: dict[str, Any]) -> None:
        data = strict_json.canonical_file_bytes(payload)
        self.send_response(status)
        self.send_header("Content-Type", "application/json")
        self.send_header("Content-Length", str(len(data)))
        self.end_headers()
        self.wfile.write(data)

    def _error(self, status: int, kind: str, message: str) -> None:
        self._send_json(
            status, {"type": "error", "error": {"type": kind, "message": message}}
        )

    def do_GET(self) -> None:
        if self.path == "/healthz":
            self._send_json(200, {"status": "ok"})
            return
        self._error(404, "not_found_error", "probe: unknown path")

    def do_POST(self) -> None:
        provider: "FakeAnthropicProvider" = self.server.provider  # type: ignore[attr-defined]
        values = self.headers.get_all("Content-Length") or []
        if not values:
            self.close_connection = True
            self._error(411, "invalid_request_error", "probe: missing Content-Length")
            return
        if len(set(values)) != 1:
            self.close_connection = True
            self._error(
                400, "invalid_request_error", "probe: conflicting Content-Length"
            )
            return
        try:
            length = int(values[0])
        except ValueError:
            self.close_connection = True
            self._error(
                400, "invalid_request_error", "probe: non-numeric Content-Length"
            )
            return
        if length < 0:
            self.close_connection = True
            self._error(
                400, "invalid_request_error", "probe: negative Content-Length"
            )
            return
        if length > _MAX_BODY_BYTES:
            self.close_connection = True
            self._error(
                413,
                "invalid_request_error",
                f"probe: body exceeds {_MAX_BODY_BYTES} bytes",
            )
            return
        body = self.rfile.read(length) if length else b""
        document: Any = None
        try:
            if body:
                document = strict_json.loads(body)
        except strict_json.StrictJSONError:
            document = None
        provider._record(self.command, self.path, self.headers, body, document)
        if not isinstance(document, dict):
            self._error(
                400, "invalid_request_error", "probe: body is not a JSON object"
            )
            return
        status, payload = provider._respond(document)
        self._send_json(status, payload)


class FakeAnthropicProvider:
    """Deterministic loopback-only fake Anthropic endpoint.

    Binds ``127.0.0.1`` on an ephemeral port, answers ``GET /healthz`` and
    ``POST`` JSON requests with canned deterministic responses, and records
    request metadata in memory only. Nothing is written to disk and no
    request body, header value, or credential is retained — only the
    metadata captured in :class:`RequestRecord`.
    """

    def __init__(
        self,
        *,
        host: str = "127.0.0.1",
        responder: Callable[[dict[str, Any]], tuple[int, dict[str, Any]]] | None = None,
    ):
        if host not in _LOOPBACK_HOSTS:
            raise ProbeError(f"fake provider host {host!r} is not a loopback literal")
        self._host = host
        self._responder = responder or _default_responder
        self._server: ThreadingHTTPServer | None = None
        self._thread: threading.Thread | None = None
        self._records: list[RequestRecord] = []
        self._dropped = 0
        self._records_lock = threading.Lock()

    def start(self) -> "FakeAnthropicProvider":
        if self._server is not None:
            raise ProbeError("fake provider is already started")
        server = ThreadingHTTPServer((self._host, 0), _ProviderHandler)
        server.daemon_threads = True
        server.provider = self  # type: ignore[attr-defined]
        thread = threading.Thread(target=server.serve_forever, daemon=True)
        thread.start()
        self._server = server
        self._thread = thread
        return self

    def stop(self) -> None:
        if self._server is None:
            return
        self._server.shutdown()
        self._server.server_close()
        if self._thread is not None:
            self._thread.join(timeout=5)
        self._server = None
        self._thread = None

    def __enter__(self) -> "FakeAnthropicProvider":
        return self.start()

    def __exit__(self, *_exc: object) -> None:
        self.stop()

    @property
    def base_url(self) -> str:
        if self._server is None:
            raise ProbeError("fake provider is not started")
        host, port = self._server.server_address[:2]
        formatted = f"[{host}]" if ":" in host else host
        return f"http://{formatted}:{port}"

    @property
    def requests(self) -> tuple[RequestRecord, ...]:
        with self._records_lock:
            return tuple(self._records)

    @property
    def dropped_requests(self) -> int:
        """Records dropped after the bounded cap; spam stays evidentiary."""

        with self._records_lock:
            return self._dropped

    def _respond(self, document: dict[str, Any]) -> tuple[int, dict[str, Any]]:
        return self._responder(document)

    def _record(
        self, method: str, path: str, headers: Any, body: bytes, document: Any
    ) -> None:
        presented = headers.get("x-api-key") or ""
        if not presented:
            bearer = headers.get("Authorization") or ""
            presented = bearer[7:] if bearer.startswith("Bearer ") else bearer
        if not presented:
            auth = "absent"
        elif presented == DUMMY_TOKEN:
            auth = "dummy"
        else:
            auth = "other"
        model: str | None = None
        tool_names: tuple[str, ...] = ()
        has_system = False
        if isinstance(document, dict):
            candidate = document.get("model")
            model = candidate if isinstance(candidate, str) else None
            tools = document.get("tools")
            if isinstance(tools, list):
                tool_names = tuple(
                    tool["name"]
                    for tool in tools
                    if isinstance(tool, dict) and isinstance(tool.get("name"), str)
                )
            has_system = "system" in document
        record = RequestRecord(
            method=method,
            path=path,
            model=model,
            tool_names=tool_names,
            has_system=has_system,
            auth=auth,
            body_sha256=strict_json.sha256_hex(body),
        )
        with self._records_lock:
            if len(self._records) >= _RECORD_CAP:
                self._dropped += 1
            else:
                self._records.append(record)


# -------------------------------------------------------------- native run


@dataclass(frozen=True)
class TrustedExecutable:
    """Pinned executable identity: exact resolved path and full SHA-256.

    ``fake=True`` marks a unit-test fake executable; anything else is a
    real native artifact and additionally requires proven P0 daemon
    isolation before it may run.
    """

    resolved_path: Path
    sha256: str
    fake: bool = False


def trusted_from_contract(native_contract: dict[str, Any]) -> TrustedExecutable:
    """Derive the trusted spec from the native-contract executable record."""

    try:
        record = native_contract["claude"]["executable"]
        resolved = record["resolved_path"]
        digest = record["sha256"]
    except (KeyError, TypeError) as exc:
        raise ProbeError(
            f"native contract lacks the claude.executable identity: {exc}"
        ) from exc
    if not isinstance(resolved, str) or not resolved:
        raise ProbeError("native contract resolved_path must be a nonempty string")
    if not isinstance(digest, str) or not _SHA256_RE.fullmatch(digest):
        raise ProbeError("native contract sha256 must be 64 lowercase hex digits")
    return TrustedExecutable(Path(resolved), digest, fake=False)


@dataclass(frozen=True)
class NativeRunResult:
    """Bounded outcome of one gated native run inside the fixture."""

    argv: tuple[str, ...]
    returncode: int | None  # None when the timeout killed the child
    timed_out: bool
    stdout: str
    stderr: str
    requests: tuple[RequestRecord, ...]


def _sha256_file(path: Path) -> str:
    digest = hashlib.sha256()
    with open(path, "rb") as handle:
        for chunk in iter(lambda: handle.read(8 * 1024 * 1024), b""):
            digest.update(chunk)
    return digest.hexdigest()


def _verify_trusted_executable(trusted: TrustedExecutable) -> Path:
    """Verify the artifact exactly matches the pinned spec (fail closed).

    Identity is the exact absolute non-symlink path plus the full content
    SHA-256; group/other-writable artifacts are refused. Owner identity is
    deliberately not required: a root-owned immutable artifact at the exact
    pinned path with the pinned hash is acceptable, and an arbitrary user
    script is rejected unless a spec pins its exact path and hash.
    """

    path = trusted.resolved_path
    if not isinstance(trusted.sha256, str) or not _SHA256_RE.fullmatch(
        trusted.sha256
    ):
        raise ProbeError("trusted executable spec sha256 must be 64 lowercase hex")
    if not path.is_absolute():
        raise ProbeError(f"probe executable {path} must be an absolute path")
    real = Path(os.path.realpath(path))
    if real != path:
        raise ProbeError(
            f"probe executable {path} must not contain non-normal components "
            f"or resolve through a symlink"
        )
    try:
        info = os.lstat(real)
    except FileNotFoundError as exc:
        raise ProbeError(f"probe executable {real} does not exist") from exc
    if not stat.S_ISREG(info.st_mode):
        raise ProbeError(f"probe executable {real} is not a regular file")
    if stat.S_IMODE(info.st_mode) & 0o022:
        raise ProbeError(
            f"probe executable {real} must not be group/other-writable"
        )
    if not os.access(real, os.X_OK):
        raise ProbeError(f"probe executable {real} is not executable")
    if _sha256_file(real) != trusted.sha256:
        raise ProbeError(
            f"probe executable {real} content hash does not match the trusted "
            "executable spec"
        )
    return real


def _kill_process_group(process: subprocess.Popen) -> None:
    try:
        os.killpg(os.getpgid(process.pid), signal.SIGKILL)
    except (ProcessLookupError, PermissionError):
        pass


def run_native(
    args: list[str] | tuple[str, ...],
    *,
    trusted: TrustedExecutable,
    fixture: ProbeFixture,
    provider: FakeAnthropicProvider | None = None,
    timeout: float = 60.0,
) -> NativeRunResult:
    """Run the trusted executable once inside the disposable fixture.

    The real (``fake=False``) spec is refused before any hashing or
    provider startup: real native execution belongs to the P0 namespace
    mechanism. Fake-executable unit probes are verified against the pinned
    spec (exact path, full SHA-256, non-writable) before anything starts.
    The child receives only the fixture environment (loopback fake provider
    with the dummy token, zero real credentials, no ambient variables),
    runs in a new session/process group with the disposable HOME as CWD and
    a null stdin, and the whole process group is SIGKILLed and reaped on
    timeout or error. A caller-supplied provider keeps its lifecycle; an
    internally created one is stopped deterministically.
    """

    if timeout <= 0:
        raise ProbeError("probe run timeout must be positive")
    if not trusted.fake:
        # Refuse real specs before any hashing or provider startup.
        raise ProbeError(_P0_REFUSAL)
    executable = _verify_trusted_executable(trusted)
    command = (str(executable), *[str(argument) for argument in args])
    owned = provider is None
    if owned:
        provider = FakeAnthropicProvider().start()
    assert provider is not None
    try:
        env = fixture.environ(base_url=provider.base_url)
        process = subprocess.Popen(
            list(command),
            cwd=fixture.home,
            env=env,
            stdin=subprocess.DEVNULL,
            stdout=subprocess.PIPE,
            stderr=subprocess.PIPE,
            text=True,
            start_new_session=True,
        )
        timed_out = False
        try:
            stdout, stderr = process.communicate(timeout=timeout)
            returncode: int | None = process.returncode
        except subprocess.TimeoutExpired:
            timed_out = True
            _kill_process_group(process)
            stdout, stderr = process.communicate()
            returncode = None
        except BaseException:
            _kill_process_group(process)
            process.wait()
            raise
        return NativeRunResult(
            argv=command,
            returncode=returncode,
            timed_out=timed_out,
            stdout=stdout[-4000:],
            stderr=stderr[-4000:],
            requests=provider.requests,
        )
    finally:
        if owned:
            provider.stop()


# --------------------------------------------------------------------- CLI


_SELFTEST_FAKE_BODY = (
    "#!/bin/sh\n"
    "echo P0-SELF-TEST-OK\n"
    'echo "HOME=$HOME"\n'
    'if [ -w "$0" ]; then echo BINARY-WRITABLE; else echo BINARY-READONLY; fi\n'
)


def _p0_self_test(fixture: ProbeFixture, *, environ: Mapping[str, str] | None = None):
    """Exercise the P0 namespace mechanism with a harmless fake executable."""

    from . import p0

    stage = state.ensure_private_dir(fixture.root / "selftest")
    script = stage / "p0-fake-claude"
    state.atomic_write(script, _SELFTEST_FAKE_BODY.encode("utf-8"))
    os.chmod(script, 0o700)
    trusted = TrustedExecutable(script, _sha256_file(script), fake=True)
    return p0.run_p0(
        trusted=trusted,
        fixture=fixture,
        timeout=60.0,
        evidence_name="p0-self-test",
        environ=environ,
    )


def probe_cli(
    positionals: list[str],
    flags: dict[str, Any],
    run_argv: list[str],
    *,
    environ: Mapping[str, str] | None = None,
) -> int:
    """Gated CLI for the disposable probe harness; returns a process exit code.

    ``--allow-local-claude`` is presence-based explicit consent: its value
    is ignored and it never relaxes any other check. ``probe init`` takes no
    executable argv. ``probe run`` requires ``--native-contract FILE`` and
    passes any argv after ``--`` to the contract-pinned executable; with
    ``--p0`` it runs inside the P0 namespace mechanism, which additionally
    requires the separate presence-based ``--allow-real-execution`` flag
    for the real contract binary. Without ``--p0`` the CLI run path always
    refuses the real (contract) spec, so its evidence branch is reachable
    only from API-level fake-spec unit probes. ``probe p0-self-test``
    exercises the P0 mechanism with a harmless fake executable and takes no
    argv.
    """

    ambient = os.environ if environ is None else environ
    try:
        if "allow-local-claude" not in flags:
            raise ProbeError("probe requires explicit --allow-local-claude consent")
        fixture_root = flags.get("fixture-root")
        if not isinstance(fixture_root, str) or not fixture_root:
            raise ProbeError("probe requires --fixture-root PATH")
        assert_no_provider_credentials(ambient)
        action = positionals[0] if positionals else ""
        if action == "init":
            if run_argv:
                raise ProbeError("probe init takes no executable argv")
            fixture = build_fixture(fixture_root, environ=ambient)
            sys.stdout.write(
                strict_json.canonical_file_bytes(fixture_manifest(fixture)).decode(
                    "utf-8"
                )
            )
            return 0
        if action == "p0-self-test":
            if run_argv:
                raise ProbeError("probe p0-self-test takes no executable argv")
            fixture = build_fixture(fixture_root, environ=ambient)
            result = _p0_self_test(fixture, environ=ambient)
            print(
                f"p0 self-test: returncode={result.run.get('returncode')} "
                f"assertions={len(result.report.get('assertions', {}))} "
                f"evidence={result.evidence}"
            )
            return 0
        if action == "run":
            contract_path = flags.get("native-contract")
            if not isinstance(contract_path, str) or not contract_path:
                raise ProbeError("probe run requires --native-contract FILE")
            if "allow-real-execution" in flags and "p0" not in flags:
                raise ProbeError(
                    "--allow-real-execution is only valid together with --p0"
                )
            contract = strict_json.load(Path(contract_path))
            if not isinstance(contract, dict):
                raise ProbeError("native contract must be a JSON object")
            trusted = trusted_from_contract(contract)
            fixture = build_fixture(fixture_root, environ=ambient)
            if "p0" in flags:
                from . import p0

                outcome = p0.run_p0(
                    trusted=trusted,
                    fixture=fixture,
                    args=tuple(run_argv),
                    allow_real="allow-real-execution" in flags,
                    evidence_name="p0-last-run",
                    environ=ambient,
                )
                print(
                    f"probe run: returncode={outcome.run.get('returncode')} "
                    f"timed_out={outcome.run.get('timed_out')} "
                    f"requests={len(outcome.report.get('requests', ()))} "
                    f"evidence={outcome.evidence}"
                )
                if outcome.run.get("timed_out") or outcome.run.get("returncode") != 0:
                    return 2
                return 0
            result = run_native(run_argv, trusted=trusted, fixture=fixture)
            # Metadata-only evidence (ora-28): this branch is reachable only
            # from API-level fake-spec probes, and even there raw argv and
            # stdio text are never persisted.
            argv_joined = "\n".join(result.argv).encode("utf-8")
            stdout_bytes = result.stdout.encode("utf-8")
            stderr_bytes = result.stderr.encode("utf-8")
            evidence = {
                "version": 1,
                "kind": "probe-run",
                "run": {
                    "returncode": result.returncode,
                    "timed_out": result.timed_out,
                    "argv_count": len(result.argv),
                    "argv_sha256": strict_json.sha256_hex(argv_joined),
                    "stdout_bytes": len(stdout_bytes),
                    "stdout_sha256": strict_json.sha256_hex(stdout_bytes),
                    "stderr_bytes": len(stderr_bytes),
                    "stderr_sha256": strict_json.sha256_hex(stderr_bytes),
                },
                "requests": [asdict(record) for record in result.requests],
            }
            path = write_evidence(fixture, "last-run", evidence)
            print(
                f"probe run: returncode={result.returncode} "
                f"timed_out={result.timed_out} requests={len(result.requests)}"
            )
            print(f"evidence: {path}")
            if result.timed_out or result.returncode != 0:
                return 2
            return 0
        raise ProbeError(
            f"unknown probe action {action!r}; "
            "expected 'init', 'run', or 'p0-self-test'"
        )
    except (ProbeError, state.StateError, strict_json.StrictJSONError, OSError) as exc:
        print(f"claude-multi-dev: probe: {exc}", file=sys.stderr)
        return 2
