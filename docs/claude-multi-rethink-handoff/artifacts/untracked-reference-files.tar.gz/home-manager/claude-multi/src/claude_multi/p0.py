"""P0 namespace isolation for the probe harness (ora-24 final design).

This module is the parent-side orchestrator. It spawns the pinned (or a
fake unit-test) executable inside disposable user/mount/network/PID/UTS/IPC
namespaces so the live uid-shared daemon domain, host filesystem, host IPC,
host keyring payload, and host network are unreachable from the probe. The
inner reporter (:mod:`claude_multi.p0inner`) performs all in-namespace
assertions; this module verifies everything from the parent side and is the
only evidence writer.

Outer wrapper contract: ``unshare --user --map-root-user --mount --net
--pid --uts --ipc --fork --kill-child=SIGKILL`` running the inner reporter
as PID 1. The parent additionally runs in its own process group
(``start_new_session``) with a group-kill watchdog, so teardown is proven
with zero survivors.

Fail-closed posture: any missing binary, unsupported kernel feature,
payload key in the ambient keyring domain, contact with a host canary,
surviving namespace process, tampered input, or invalid/missing bounded
report aborts without writing acceptance evidence.
"""

from __future__ import annotations

import ctypes
import math
import os
import platform
import secrets
import shutil
import signal
import socket
import subprocess
import sys
import threading
import time
from dataclasses import dataclass
from pathlib import Path
from typing import Any, Callable, Mapping

from . import probe, strict_json


class P0Unsupported(probe.ProbeError):
    """A required kernel/binary feature is unavailable (skippable)."""


_REQUIRED_BINARIES = ("unshare", "ip")
_NS_NAMES = ("user", "mnt", "net", "pid", "uts", "ipc")
_REPORT_CAP = 64 * 1024
_CONTROL_CAP = 256 * 1024

_RESIDUALS = (
    "supplementary groups: kernel-propagated setgroups=deny prevents emptying "
    "group lists inside unprivileged user namespaces; residual entries are "
    "overflow(65534) placeholders for unmapped host groups plus the mapped "
    "gid, which grant nothing inside the private mount domain",
    "keyring: accepted same-kuid malicious reattachment residual; preflight "
    "verified zero payload keys and the reporter joined a fresh anonymous "
    "session keyring",
    "rlimits: RLIMIT_NPROC omitted because host-kuid process accounting is "
    "host-wide and cannot bound the namespace independently",
)


def residuals() -> tuple[str, ...]:
    return _RESIDUALS


# --------------------------------------------------------------- preflight


@dataclass(frozen=True)
class Preflight:
    uid: int
    gid: int
    hostname: str
    namespaces: dict[str, str]
    payload_keys: int  # always 0 when preflight succeeds
    binaries: dict[str, str]  # required tool name -> resolved absolute path


def _namespace_identities() -> dict[str, str]:
    identities: dict[str, str] = {}
    for name in _NS_NAMES:
        path = Path(f"/proc/self/ns/{name}")
        if not path.exists():
            raise P0Unsupported(f"namespace handle {path} is unavailable")
        identities[name] = os.readlink(path)
    return identities


def resolve_binaries(
    environ: Mapping[str, str],
    *,
    which: Callable[..., str | None] = shutil.which,
) -> dict[str, str]:
    """Resolve every required tool to an absolute path via the ambient PATH.

    Only raw-syscall-backed operations are used for mount/keyctl, so those
    binaries are deliberately not required.
    """

    resolved: dict[str, str] = {}
    missing: list[str] = []
    for name in _REQUIRED_BINARIES:
        candidate = which(name, path=environ.get("PATH"))
        if candidate is None:
            missing.append(name)
            continue
        resolved[name] = candidate
    if missing:
        raise P0Unsupported("missing required binaries: " + ", ".join(missing))
    return resolved


def probe_userns_feature(
    unshare: str,
    runner: Callable[..., Any] = subprocess.run,
) -> None:
    """Prove the full required namespace set with the resolved unshare.

    The payload is the absolute current interpreter, never an ambient-PATH
    tool; any spawn failure classifies as P0Unsupported, not a raw OSError.
    """

    try:
        completed = runner(
            [
                unshare,
                "--user",
                "--map-root-user",
                "--mount",
                "--net",
                "--pid",
                "--uts",
                "--ipc",
                "--fork",
                "--kill-child=SIGKILL",
                "--",
                sys.executable,
                "-c",
                "pass",
            ],
            capture_output=True,
        )
    except OSError as exc:
        raise P0Unsupported(f"namespace feature probe cannot run: {exc}") from exc
    if completed.returncode != 0:
        raise P0Unsupported(
            "unprivileged user/mount/net/pid/uts/ipc namespaces are unavailable"
        )


def parse_proc_keys(text: str, uid: int) -> None:
    """Bounded keyring claim: only empty structural uid rings are permitted.

    Any payload key, any extra named/persistent keyring, or a non-empty uid
    user ring blocks. Key names and content are never read into diagnostics.
    """

    structural = {"_ses", f"_uid.{uid}", f"_uid_ses.{uid}"}
    for line in text.splitlines():
        if not line.strip():
            continue
        parts = line.split(None, 8)
        if len(parts) < 9:
            raise probe.ProbeError("unparseable /proc/keys entry; refusing")
        key_type, description = parts[7], parts[8]
        base = description.split(": ", 1)[0]
        if key_type != "keyring":
            raise probe.ProbeError(
                "payload key present in the ambient keyring domain; refusing"
            )
        if base not in structural:
            raise probe.ProbeError(
                "non-structural keyring present in the ambient keyring domain; "
                "refusing"
            )
        if base == f"_uid.{uid}" and description != f"_uid.{uid}: empty":
            raise probe.ProbeError("uid user keyring is not empty; refusing")


def preflight(
    environ: Mapping[str, str] | None = None,
    *,
    which: Callable[[str], str | None] = shutil.which,
    runner: Callable[..., Any] = subprocess.run,
    keys_text: str | None = None,
    machine: str | None = None,
) -> Preflight:
    """Verify binaries, namespace features, and the bounded keyring claim."""

    if (machine or platform.machine()) != "x86_64":
        raise P0Unsupported("P0 keyring syscalls are validated for x86_64 only")
    ambient = os.environ if environ is None else environ
    binaries = resolve_binaries(ambient, which=which)
    identities = _namespace_identities()
    probe_userns_feature(binaries["unshare"], runner)
    if keys_text is None:
        try:
            keys_text = Path("/proc/keys").read_text(errors="replace")
        except OSError as exc:
            raise P0Unsupported(f"/proc/keys is unreadable: {exc}") from exc
    parse_proc_keys(keys_text, os.getuid())
    return Preflight(
        uid=os.getuid(),
        gid=os.getgid(),
        hostname=socket.gethostname(),
        namespaces=identities,
        payload_keys=0,
        binaries=binaries,
    )


# ---------------------------------------------------------------- canaries


class Canaries:
    """Unique host listeners/artifacts the namespace must never touch."""

    _SYSV_RMID = 0
    _SYSV_STAT = 2

    def __init__(self, run_id: str):
        self.run_id = run_id
        self.tcp: socket.socket | None = None
        self.tcp_port: int | None = None
        self.unix: socket.socket | None = None
        self.unix_path: Path | None = None
        self.shm_path: Path | None = None
        self.shm_content: bytes | None = None
        self.sysv_shmid: int | None = None
        self._libc = ctypes.CDLL("libc.so.6", use_errno=True)
        try:
            tcp = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
            self.tcp = tcp
            tcp.setsockopt(socket.SOL_SOCKET, socket.SO_REUSEADDR, 1)
            tcp.bind(("127.0.0.1", 0))
            tcp.listen(4)
            tcp.setblocking(False)
            self.tcp_port = tcp.getsockname()[1]

            unix_path = Path(f"/tmp/cm-p0-canary-{run_id}.sock")
            self.unix_path = unix_path
            unix = socket.socket(socket.AF_UNIX, socket.SOCK_STREAM)
            self.unix = unix
            unix.bind(str(unix_path))
            unix.listen(4)
            unix.setblocking(False)

            self.shm_content = secrets.token_bytes(16)
            shm_path = Path(f"/dev/shm/cm-p0-canary-{run_id}")
            self.shm_path = shm_path
            shm_path.write_bytes(self.shm_content)

            shmid = self._libc.shmget(0, 64, 0o600)  # IPC_PRIVATE
            if shmid < 0:
                raise probe.ProbeError(
                    f"cannot create SysV canary: {os.strerror(ctypes.get_errno())}"
                )
            self.sysv_shmid = shmid
        except BaseException:
            self.close()
            raise

    @staticmethod
    def _count_pending(listener: socket.socket) -> int:
        contacts = 0
        while True:
            try:
                connection, _ = listener.accept()
            except (BlockingIOError, InterruptedError):
                return contacts
            connection.close()
            contacts += 1

    def verify(self) -> dict[str, Any]:
        """Zero-contact proof; any contact or tamper fails closed."""

        assert self.tcp is not None and self.unix is not None
        assert self.shm_path is not None and self.shm_content is not None
        result = {
            "tcp_contacts": self._count_pending(self.tcp),
            "unix_contacts": self._count_pending(self.unix),
            "shm_intact": self.shm_path.read_bytes() == self.shm_content,
        }
        status = ctypes.create_string_buffer(256)
        result["sysv_intact"] = (
            self._libc.shmctl(self.sysv_shmid, self._SYSV_STAT, status) == 0
        )
        problems = []
        if result["tcp_contacts"] or result["unix_contacts"]:
            problems.append("host listener recorded a contact")
        if not result["shm_intact"]:
            problems.append("host /dev/shm canary was modified")
        if not result["sysv_intact"]:
            problems.append("host SysV canary was removed")
        if problems:
            raise probe.ProbeError("canary violation: " + "; ".join(problems))
        return result

    def close(self) -> None:
        for listener in (self.tcp, self.unix):
            if listener is not None:
                try:
                    listener.close()
                except OSError:
                    pass
        self.tcp = None
        self.unix = None
        for path in (self.unix_path, self.shm_path):
            if path is not None:
                try:
                    path.unlink(missing_ok=True)
                except OSError:
                    pass
        self.unix_path = None
        self.shm_path = None
        if self.sysv_shmid is not None:
            self._libc.shmctl(self.sysv_shmid, self._SYSV_RMID, None)
            self.sysv_shmid = None

    def __enter__(self) -> "Canaries":
        return self

    def __exit__(self, *_exc: object) -> None:
        self.close()


# --------------------------------------------------------- construction API


def build_unshare_argv(unshare: str) -> list[str]:
    """Exact outer wrapper: mapped-root user ns plus mount/net/pid/uts/ipc.

    ``unshare`` is the absolute path resolved during preflight, so the gate
    proves exactly the executable that is used.
    """

    return [
        unshare,
        "--user",
        "--map-root-user",
        "--mount",
        "--net",
        "--pid",
        "--uts",
        "--ipc",
        "--fork",
        "--kill-child=SIGKILL",
        "--",
        sys.executable,
        "-m",
        "claude_multi.p0inner",
    ]


def build_inner_env(run_id: str) -> dict[str, str]:
    """Minimal reporter environment: no ambient variables, no credentials."""

    src = Path(probe.__file__).resolve().parent.parent
    return {
        "PATH": "/usr/bin:/bin",
        "PYTHONPATH": str(src),
        "P0_RUN_ID": run_id,
    }


def build_control_config(
    *,
    preflight_info: Preflight,
    canaries: Canaries,
    trusted: probe.TrustedExecutable,
    executable_info: os.stat_result,
    fixture: probe.ProbeFixture,
    args: tuple[str, ...],
    timeout: float,
    use_pty: bool,
    fault_injection: str | None = None,
) -> dict[str, Any]:
    """Parent→reporter configuration; serialized as the first control line.

    The capability nonce is deliberately not part of this structure: it
    travels only as the second control line and nowhere else.
    """

    config: dict[str, Any] = {
        "uid": preflight_info.uid,
        "gid": preflight_info.gid,
        "host_hostname": preflight_info.hostname,
        "host_namespaces": preflight_info.namespaces,
        "binaries": {"ip": preflight_info.binaries["ip"]},
        "canary": {
            "tcp_port": canaries.tcp_port,
            "unix_path": str(canaries.unix_path),
            "shm_path": str(canaries.shm_path),
            "sysv_shmid": canaries.sysv_shmid,
        },
        "binary": {
            "source": str(trusted.resolved_path),
            "target_name": trusted.resolved_path.name,
            "sha256": trusted.sha256,
            "dev": executable_info.st_dev,
            "ino": executable_info.st_ino,
        },
        "fixture": {"source": str(fixture.root), "target": "/run/claude-multi-p0/fixture"},
        "run": {
            "args": list(args),
            "timeout": timeout,
            "cpu_seconds": max(1, int(timeout)) + 30,
            "as_bytes": 4 * 1024 * 1024 * 1024,
            "nofile": 256,
            "fsize_bytes": 16 * 1024 * 1024,
            "use_pty": use_pty,
        },
    }
    if fault_injection is not None:
        config["fault_injection"] = fault_injection
    return config


# ------------------------------------------------------------ report intake


def _write_all(fd: int, data: bytes, what: str) -> None:
    """Fully write a bounded payload with a ProbeError taxonomy."""

    if len(data) > _CONTROL_CAP:
        raise probe.ProbeError(f"{what}: payload exceeds the {_CONTROL_CAP}-byte bound")
    view = memoryview(data)
    while view:
        try:
            written = os.write(fd, view)
        except BrokenPipeError as exc:
            raise probe.ProbeError(
                f"{what}: the inner reporter closed the control channel"
            ) from exc
        except OSError as exc:
            raise probe.ProbeError(f"{what}: control write failed: {exc}") from exc
        view = view[written:]


def _mountinfo_unescape(field: str) -> str:
    """Decode mountinfo octal escapes (space, tab, newline, backslash)."""

    return (
        field.replace("\\040", " ")
        .replace("\\011", "\t")
        .replace("\\012", "\n")
        .replace("\\134", "\\")
    )


def _mountinfo_holds_marker(text: str, marker: str) -> bool:
    """True when any mountinfo root/mountpoint field matches the marker.

    Compares escape-decoded fields exactly or as a path-component prefix,
    never as a raw substring (which could false-positive on sibling names).
    """

    for line in text.splitlines():
        fields = line.split(" ")
        if len(fields) < 5:
            continue
        for field in (fields[3], fields[4]):
            decoded = _mountinfo_unescape(field)
            if decoded == marker or decoded.startswith(marker.rstrip("/") + "/"):
                return True
    return False


def _read_capped(fd: int, limit: int) -> tuple[bytes, bool]:
    """Drain an fd, retaining at most ``limit`` bytes; flags oversize."""

    chunks: list[bytes] = []
    total = 0
    oversize = False
    while True:
        try:
            data = os.read(fd, 4096)
        except OSError:
            break
        if not data:
            break
        total += len(data)
        if total > limit:
            oversize = True
            continue
        chunks.append(data)
    return b"".join(chunks), oversize


def validate_report(raw: bytes, nonce: str, *, oversize: bool = False) -> dict[str, Any]:
    """Bounded nonce/schema validation of the inner reporter's report."""

    if oversize or not raw:
        raise probe.ProbeError("inner report missing or exceeds the bounded size")
    try:
        document = strict_json.loads(raw)
    except strict_json.StrictJSONError as exc:
        raise probe.ProbeError(f"inner report is not strict JSON: {exc}") from exc
    if not isinstance(document, dict) or document.get("schema") != "p0-report/1":
        raise probe.ProbeError("inner report has an unknown schema")
    if document.get("nonce") != nonce:
        raise probe.ProbeError("inner report nonce mismatch")
    assertions = document.get("assertions")
    if not isinstance(assertions, dict) or not assertions:
        raise probe.ProbeError("inner report carries no assertions")
    for name, value in sorted(assertions.items()):
        if value != "pass":
            raise probe.ProbeError(f"inner assertion failed: {name}")
    return document


def _assert_no_survivors(pgid: int, marker: str, *, grace: float = 5.0) -> None:
    """Prove the namespace tree is gone: empty group and no mount holder.

    The reporter's native child forms its own session/group, so the group
    check alone is insufficient; any process still holding the private mount
    domain (visible via the unique fixture bind source) is a survivor.
    Reaping is asynchronous, hence the bounded grace window.
    """

    deadline = time.monotonic() + grace
    while True:
        try:
            os.killpg(pgid, 0)
            group_alive = True
        except ProcessLookupError:
            group_alive = False
        except PermissionError:
            group_alive = True
        holder: str | None = None
        if not group_alive:
            for entry in os.scandir("/proc"):
                if not entry.name.isdigit():
                    continue
                try:
                    mountinfo = Path(entry.path, "mountinfo").read_text(
                        errors="replace"
                    )
                except OSError:
                    continue
                if _mountinfo_holds_marker(mountinfo, marker):
                    holder = entry.name
                    break
        if not group_alive and holder is None:
            return
        if time.monotonic() >= deadline:
            if group_alive:
                raise probe.ProbeError("namespace process group survived teardown")
            raise probe.ProbeError(
                f"namespace survivor process {holder} still holds the private "
                "mount domain"
            )
        time.sleep(0.05)


# -------------------------------------------------------------------- run


_RUN_METADATA_KEYS = (
    "returncode",
    "timed_out",
    "argv_count",
    "argv_sha256",
    "stdout_bytes",
    "stdout_sha256",
    "stdout_truncated",
    "stderr_bytes",
    "stderr_sha256",
    "stderr_truncated",
)


def _redact_run_for_evidence(run: dict[str, Any]) -> dict[str, Any]:
    """Metadata-only run evidence (ora-28).

    Exit status, timing, byte counts, content hashes and truncation flags
    only. Raw native stdout/stderr text and user argv are never copied, so
    persisting them is structurally impossible regardless of the fake flag.
    """

    return {key: run.get(key) for key in _RUN_METADATA_KEYS}


@dataclass(frozen=True)
class P0Result:
    report: dict[str, Any]
    run: dict[str, Any]
    canaries: dict[str, Any]
    evidence: Path | None


def run_p0(
    *,
    trusted: probe.TrustedExecutable,
    fixture: probe.ProbeFixture,
    args: tuple[str, ...] = (),
    timeout: float = 120.0,
    allow_real: bool = False,
    use_pty: bool = False,
    evidence_name: str | None = None,
    environ: Mapping[str, str] | None = None,
    parent_timeout: float | None = None,
    fault_injection: str | None = None,
    popen: Callable[..., Any] = subprocess.Popen,
    kill_group: Callable[[int, int], None] = os.killpg,
) -> P0Result:
    """Run the trusted executable inside the disposable P0 namespaces.

    The parent snapshots input identity first, spawns the outer ``unshare``
    wrapper (resolved absolute path) in its own process group, then — only
    after complete teardown with zero survivors, untouched canaries,
    re-verified inputs, and a valid bounded nonce report — optionally
    writes evidence. Evidence is metadata-only: exit status, timing, byte
    counts, content hashes and truncation flags; raw native stdout/stderr
    text and user argv are never persisted. ``fault_injection`` is a
    test-only hook that forces an inner assertion failure. Any failure
    writes no acceptance evidence.
    """

    if not trusted.fake and not allow_real:
        raise probe.ProbeError(
            "P0 real native execution requires the separate explicit "
            "--allow-real-execution flag"
        )
    if timeout <= 0 or not math.isfinite(timeout):
        raise probe.ProbeError("P0 run timeout must be finite and positive")
    if parent_timeout is not None and (
        parent_timeout <= 0 or not math.isfinite(parent_timeout)
    ):
        raise probe.ProbeError("P0 parent timeout must be finite and positive")
    executable = probe._verify_trusted_executable(trusted)
    executable_info = os.stat(executable)
    snapshot = (executable_info.st_dev, executable_info.st_ino)
    ambient = os.environ if environ is None else environ
    info = preflight(ambient)

    run_id = secrets.token_hex(8)
    nonce = secrets.token_hex(32)
    canaries = Canaries(run_id)
    control_r = control_w = report_r = report_w = -1
    process: Any = None
    try:
        control_r, control_w = os.pipe2(os.O_CLOEXEC)
        report_r, report_w = os.pipe2(os.O_CLOEXEC)
        config = build_control_config(
            preflight_info=info,
            canaries=canaries,
            trusted=trusted,
            executable_info=executable_info,
            fixture=fixture,
            args=args,
            timeout=timeout,
            use_pty=use_pty,
            fault_injection=fault_injection,
        )
        env = build_inner_env(run_id)
        env["P0_CONTROL_FD"] = str(control_r)
        env["P0_REPORT_FD"] = str(report_w)
        process = popen(
            build_unshare_argv(info.binaries["unshare"]),
            env=env,
            stdin=subprocess.DEVNULL,
            stdout=subprocess.PIPE,
            stderr=subprocess.PIPE,
            pass_fds=(control_r, report_w),
            start_new_session=True,
            close_fds=True,
        )
        os.close(report_w)
        report_w = -1
        payload = strict_json.canonical_bytes(config) + b"\n" + nonce.encode() + b"\n"
        _write_all(control_w, payload, "control configuration")
        os.close(control_w)
        control_w = -1
        os.close(control_r)
        control_r = -1

        report_box: dict[str, Any] = {}

        def _reader() -> None:
            try:
                report_box["raw"], report_box["oversize"] = _read_capped(
                    report_r, _REPORT_CAP
                )
            except OSError:
                report_box["raw"], report_box["oversize"] = b"", False

        reader = threading.Thread(target=_reader, daemon=True)
        reader.start()
        watchdog = parent_timeout if parent_timeout is not None else timeout + 60.0
        try:
            _stdout, stderr = process.communicate(timeout=watchdog)
        except subprocess.TimeoutExpired:
            kill_group(process.pid, signal.SIGKILL)
            try:
                process.communicate(timeout=10)
            except subprocess.TimeoutExpired:
                raise probe.ProbeError(
                    "namespace process did not reap after SIGKILL; possible "
                    "D-state; no acceptance evidence"
                )
            _assert_no_survivors(process.pid, str(fixture.root))
            raise probe.ProbeError(
                "namespace watchdog fired; the P0 run exceeded its parent bound"
            )
        reader.join(timeout=10)
        if process.returncode != 0:
            detail = (stderr or "")[-800:].strip()
            raise probe.ProbeError(
                f"inner reporter failed (exit {process.returncode}): {detail}"
            )
        _assert_no_survivors(process.pid, str(fixture.root))
        canary_result = canaries.verify()

        # Input re-verification: the artifact hashed at snapshot time must be
        # the artifact that ran.
        current = os.stat(executable)
        if (current.st_dev, current.st_ino) != snapshot:
            raise probe.ProbeError("trusted executable inode changed during the run")
        if probe._sha256_file(executable) != trusted.sha256:
            raise probe.ProbeError("trusted executable content changed during the run")

        report = validate_report(
            report_box.get("raw", b""), nonce, oversize=report_box.get("oversize", False)
        )
        run = report.get("run", {})
        evidence_path: Path | None = None
        if evidence_name is not None:
            # The raw capability nonce is validated in memory only; it is
            # never persisted alongside its hash.
            redacted_report = {
                key: value for key, value in report.items() if key != "nonce"
            }
            redacted_report["run"] = _redact_run_for_evidence(run)
            evidence = {
                "version": 1,
                "kind": "p0-run",
                "fixture": str(fixture.root),
                "trusted": {
                    "path": str(executable),
                    "sha256": trusted.sha256,
                    "dev": snapshot[0],
                    "ino": snapshot[1],
                    "fake": trusted.fake,
                },
                "nonce_sha256": strict_json.sha256_hex(nonce.encode()),
                "canaries": canary_result,
                "report": redacted_report,
                "keyring": {"payload_keys": 0, "status": "bounded"},
                "residuals": list(_RESIDUALS),
            }
            evidence_path = probe.write_evidence(fixture, evidence_name, evidence)
        return P0Result(
            report=report, run=run, canaries=canary_result, evidence=evidence_path
        )
    finally:
        for descriptor in (control_r, control_w, report_r, report_w):
            if descriptor >= 0:
                try:
                    os.close(descriptor)
                except OSError:
                    pass
        if process is not None and process.poll() is None:
            try:
                kill_group(process.pid, signal.SIGKILL)
            except (ProcessLookupError, PermissionError):
                pass
            try:
                process.wait(timeout=10)
            except Exception:
                pass
        canaries.close()
