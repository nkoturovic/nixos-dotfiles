"""P0 inner reporter: PID 1 inside the disposable probe namespaces.

Executed as ``python3 -m claude_multi.p0inner`` under the outer ``unshare``
wrapper built by :mod:`claude_multi.p0`. All imports resolve before the
mount phase masks host paths. The reporter:

1. makes the mount namespace private, then builds the private filesystem:
   bounded tmpfs masks over ``/home``, ``/root``, ``/tmp``, ``/var/tmp``
   (rw) and ``/sys`` (ro), a fresh ``hidepid=2,subset=pid`` ``/proc``, the
   declared fixture bound writable (nosuid/nodev) and the exact trusted
   executable bound read-only under ``/run/claude-multi-p0``, and a minimal
   ``/dev`` (null/zero/full/random/urandom with verified major:minor, fresh
   private devpts+ptmx, bounded private shm, fresh mqueue — no
   tty/log/dri/host pts) whose root is remounted read-only after setup;
2. enters a nested user namespace mapped to the derived host uid/gid and
   asserts identity: uid/gid, PID 1, namespace inode differences from the
   host, overflow-only supplementary groups (fidelity note), private
   hostname, empty routes;
3. runs IPC/network/keyring canary assertions (host loopback and unix
   listeners unreachable, host daemon/system paths masked, host port absent
   from ``/proc/self/net/tcp{,6}``, foreign SysV segment unattached, host
   shm canary absent, fresh anonymous session keyring with zero payload),
   then proves the in-namespace loopback fake provider as positive control;
4. spawns the trusted executable with ``PR_SET_DUMPABLE=0``, closed FDs,
   rlimits inherited from a bracketed reporter (CORE=0, NOFILE=256,
   FSIZE=16MiB, CPU, AS; NPROC omitted because host-kuid accounting is
   host-wide), ``/dev/null`` or private-devpts PTY stdin, bounded
   stdout/stderr captures with byte counts and hashes, and a process-group
   kill on timeout; reaps every descendant;
5. writes exactly one bounded nonce/schema report on the report FD.

Any assertion failure exits nonzero without a report; the parent then
writes no acceptance evidence.
"""

from __future__ import annotations

import contextlib
import ctypes
import hashlib
import http.client
import os
import pty
import resource
import signal
import socket
import subprocess
import sys
import threading
from pathlib import Path
from typing import Any, Iterator

from . import probe, strict_json


libc = ctypes.CDLL("libc.so.6", use_errno=True)
libc.shmat.restype = ctypes.c_void_p
libc.syscall.restype = ctypes.c_long

_SHMAT_FAILED = (1 << (ctypes.sizeof(ctypes.c_void_p) * 8)) - 1  # (void *)-1

MS_RDONLY = 1
MS_NOSUID = 2
MS_NODEV = 4
MS_NOEXEC = 8
MS_BIND = 4096
MS_REMOUNT = 32
MS_REC = 16384
MS_PRIVATE = 1 << 18
CLONE_NEWUSER = 0x10000000
PR_SET_DUMPABLE = 4
SYS_KEYCTL = 250
KEYCTL_JOIN_SESSION_KEYRING = 1
KEYCTL_READ = 11

P0_ROOT = "/run/claude-multi-p0"
_PRIVATE_HOSTNAME = "claude-multi-p0"
_DEVICE_MAJOR_MINOR = {
    "null": (1, 3),
    "zero": (1, 5),
    "full": (1, 7),
    "random": (1, 8),
    "urandom": (1, 9),
}
_DEV_EXPECTED = sorted(
    [*_DEVICE_MAJOR_MINOR, "pts", "ptmx", "shm", "mqueue"]
)
_STDIO_CAP = 64 * 1024
_REPORT_TAIL = 4 * 1024

_SUPPLEMENTARY_NOTE = (
    "kernel-propagated setgroups=deny prevents emptying group lists inside "
    "unprivileged user namespaces; residual entries are overflow(65534) "
    "placeholders for unmapped host groups plus the mapped gid"
)


class _InnerError(RuntimeError):
    """Raised on any inner assertion failure (no report is written)."""


def _mount(
    source: str | None,
    target: str,
    fstype: str | None,
    flags: int,
    data: str | None = None,
) -> None:
    result = libc.mount(
        source.encode() if source is not None else None,
        target.encode(),
        fstype.encode() if fstype is not None else None,
        flags,
        data.encode() if data is not None else None,
    )
    if result != 0:
        error = ctypes.get_errno()
        raise _InnerError(
            f"mount {target} failed: {os.strerror(error)}"
        )


def _mountinfo() -> list[list[str]]:
    lines = []
    for line in Path("/proc/self/mountinfo").read_text().splitlines():
        fields = line.split(" ")
        lines.append(fields)
    return lines


def _set_dumpable_off() -> None:
    if libc.prctl(PR_SET_DUMPABLE, 0, 0, 0, 0) != 0:
        raise _InnerError("PR_SET_DUMPABLE=0 failed")


def _read_control(fd: int) -> tuple[dict[str, Any], str]:
    buffer = bytearray()

    def _line() -> bytes:
        while True:
            newline = buffer.find(b"\n")
            if newline >= 0:
                line = bytes(buffer[:newline])
                del buffer[: newline + 1]
                return line
            chunk = os.read(fd, 4096)
            if not chunk:
                raise _InnerError("control FD closed before configuration")
            buffer.extend(chunk)
            if len(buffer) > 256 * 1024:
                raise _InnerError("control FD configuration exceeds bound")

    try:
        config_raw = _line()
        nonce_raw = _line()
    finally:
        os.close(fd)
    try:
        config = strict_json.loads(config_raw)
    except strict_json.StrictJSONError as exc:
        raise _InnerError(f"control configuration is not strict JSON: {exc}")
    if not isinstance(config, dict):
        raise _InnerError("control configuration is not an object")
    nonce = nonce_raw.decode("ascii", "replace").strip()
    if not nonce:
        raise _InnerError("control capability nonce is empty")
    return config, nonce


# -------------------------------------------------------------- phase: mounts


def _phase_mounts(config: dict[str, Any]) -> None:
    _mount(None, "/", None, MS_REC | MS_PRIVATE)
    if libc.sethostname(_PRIVATE_HOSTNAME.encode(), len(_PRIVATE_HOSTNAME)) != 0:
        raise _InnerError("sethostname failed")

    _mount("tmpfs", "/run", "tmpfs", MS_NOSUID | MS_NODEV, "size=64m,mode=755")
    for sub in ("fixture", "bin", "devsrc"):
        os.makedirs(f"{P0_ROOT}/{sub}", exist_ok=True)

    # Declared private fixture (writable, nosuid/nodev) and exact trusted
    # executable, bound before any host home/dev masking; nothing else from
    # host home is re-exposed.
    fixture_source = config["fixture"]["source"]
    fixture_target = config["fixture"]["target"]
    _mount(fixture_source, fixture_target, None, MS_BIND)
    _mount(
        fixture_source,
        fixture_target,
        None,
        MS_BIND | MS_REMOUNT | MS_NOSUID | MS_NODEV,
    )
    binary = config["binary"]
    target = f"{P0_ROOT}/bin/{binary['target_name']}"
    Path(target).touch()
    _mount(binary["source"], target, None, MS_BIND)
    _mount(
        binary["source"],
        target,
        None,
        MS_BIND | MS_REMOUNT | MS_RDONLY | MS_NOSUID | MS_NODEV,
    )

    # Stage exactly the five permitted device nodes before replacing /dev.
    for name, (major, minor) in _DEVICE_MAJOR_MINOR.items():
        source = f"/dev/{name}"
        info = os.stat(source)
        if (os.major(info.st_rdev), os.minor(info.st_rdev)) != (major, minor):
            raise _InnerError(f"host device node {source} has unexpected identity")
        staged = f"{P0_ROOT}/devsrc/{name}"
        Path(staged).touch()
        _mount(source, staged, None, MS_BIND)

    for path, data, flags in (
        ("/home", "size=4m,mode=555", MS_RDONLY),
        ("/root", "size=4m,mode=555", MS_RDONLY),
        ("/tmp", "size=32m,mode=1777", 0),
        ("/var/tmp", "size=16m,mode=1777", 0),
        ("/sys", "size=4m,mode=555", MS_RDONLY),
    ):
        _mount("tmpfs", path, "tmpfs", MS_NOSUID | MS_NODEV | flags, data)

    _mount(
        "proc",
        "/proc",
        "proc",
        MS_NOSUID | MS_NODEV | MS_NOEXEC,
        "hidepid=2,subset=pid",
    )

    _mount("tmpfs", "/dev", "tmpfs", MS_NOSUID, "size=4m,mode=755")
    os.mkdir("/dev/pts")
    os.mkdir("/dev/shm")
    os.mkdir("/dev/mqueue")
    for name in _DEVICE_MAJOR_MINOR:
        staged = f"{P0_ROOT}/devsrc/{name}"
        node = f"/dev/{name}"
        Path(node).touch()
        _mount(staged, node, None, MS_BIND)
    _mount(
        "devpts",
        "/dev/pts",
        "devpts",
        MS_NOSUID | MS_NOEXEC,
        "newinstance,ptmxmode=0666,mode=620",
    )
    os.symlink("pts/ptmx", "/dev/ptmx")
    _mount("tmpfs", "/dev/shm", "tmpfs", MS_NOSUID | MS_NODEV, "size=16m,mode=1777")
    _mount("mqueue", "/dev/mqueue", "mqueue", MS_NOSUID | MS_NODEV | MS_NOEXEC)
    # Seal the staged /dev root: no new nodes after setup. Submounts (pts,
    # shm, mqueue) keep their own writability.
    _mount(None, "/dev", None, MS_BIND | MS_REMOUNT | MS_RDONLY | MS_NOSUID)

    ip = config["binaries"]["ip"]
    subprocess.run([ip, "link", "set", "lo", "up"], check=True, capture_output=True)
    shown = subprocess.run(
        [ip, "-o", "addr", "show", "dev", "lo"],
        check=True,
        capture_output=True,
        text=True,
    ).stdout
    if "127.0.0.1/8" not in shown:
        subprocess.run(
            [ip, "addr", "add", "127.0.0.1/8", "dev", "lo"],
            check=True,
            capture_output=True,
        )


# ----------------------------------------------------------- phase: identity


def _phase_identity(config: dict[str, Any], assertions: dict[str, str]) -> dict[str, str]:
    if libc.unshare(CLONE_NEWUSER) != 0:
        raise _InnerError("nested user namespace failed")
    uid, gid = config["uid"], config["gid"]
    Path("/proc/self/uid_map").write_text(f"{uid} 0 1")
    Path("/proc/self/gid_map").write_text(f"{gid} 0 1")
    _set_dumpable_off()
    if os.getuid() != uid or os.getgid() != gid:
        raise _InnerError("nested identity does not match the derived host uid/gid")
    assertions["identity-uid-gid"] = "pass"
    if os.getpid() != 1:
        raise _InnerError("reporter is not PID 1 in its PID namespace")
    assertions["identity-pid1"] = "pass"
    groups = os.getgroups()
    if any(group not in (gid, 65534) for group in groups):
        raise _InnerError(f"unexpected mapped supplementary group: {groups}")
    assertions["identity-groups-fidelity"] = "pass"

    namespaces = {
        name: os.readlink(f"/proc/self/ns/{name}")
        for name in ("user", "mnt", "net", "pid", "uts", "ipc")
    }
    for name, identity in namespaces.items():
        if identity == config["host_namespaces"].get(name):
            raise _InnerError(f"namespace {name} is shared with the host")
    assertions["namespaces-differ"] = "pass"

    if socket.gethostname() != _PRIVATE_HOSTNAME:
        raise _InnerError("private hostname not applied")
    if socket.gethostname() == config["host_hostname"]:
        raise _InnerError("hostname is shared with the host")
    assertions["hostname-private"] = "pass"

    routes = Path("/proc/self/net/route").read_text().splitlines()
    if len(routes) > 1:
        raise _InnerError("unexpected routes inside the private net namespace")
    assertions["routes-empty"] = "pass"
    return namespaces


# --------------------------------------------------------- phase: assertions


def _assert_canaries(config: dict[str, Any], assertions: dict[str, str]) -> None:
    canary = config["canary"]
    try:
        socket.create_connection(
            ("127.0.0.1", canary["tcp_port"]), timeout=2
        ).close()
        raise _InnerError("host loopback canary is reachable")
    except _InnerError:
        raise
    except OSError:
        pass
    assertions["canary-tcp-refused"] = "pass"

    unix = socket.socket(socket.AF_UNIX, socket.SOCK_STREAM)
    try:
        unix.connect(canary["unix_path"])
        raise _InnerError("host unix canary is reachable")
    except _InnerError:
        raise
    except OSError:
        pass
    finally:
        unix.close()
    assertions["canary-unix-refused"] = "pass"

    forbidden = [
        f"/tmp/cc-daemon-{config['uid']}",
        f"/run/user/{config['uid']}/bus",
        "/run/dbus/system_bus_socket",
        "/run/systemd/private",
        "/dev/log",
    ]
    for path in forbidden:
        if os.path.exists(path):
            raise _InnerError(f"host path is visible inside the namespace: {path}")
    assertions["host-paths-masked"] = "pass"

    marker = f":{canary['tcp_port']:04X}"
    for table in ("/proc/self/net/tcp", "/proc/self/net/tcp6"):
        if not os.path.exists(table):
            continue
        if marker in Path(table).read_text():
            raise _InnerError(f"host canary port visible in {table}")
    assertions["proc-net-lacks-host-port"] = "pass"


def _assert_dev(assertions: dict[str, str]) -> None:
    entries = sorted(os.listdir("/dev"))
    if entries != _DEV_EXPECTED:
        raise _InnerError(f"unexpected /dev entries: {entries}")
    assertions["dev-exact-set"] = "pass"
    for name, (major, minor) in _DEVICE_MAJOR_MINOR.items():
        info = os.stat(f"/dev/{name}")
        if (os.major(info.st_rdev), os.minor(info.st_rdev)) != (major, minor):
            raise _InnerError(f"/dev/{name} has wrong major:minor")
    assertions["dev-major-minor"] = "pass"
    dev_fields = None
    for fields in _mountinfo():
        if fields[4] == "/dev":
            dev_fields = fields  # the covering mount is the last match
    if dev_fields is None:
        raise _InnerError("/dev mount missing from mountinfo")
    if "ro" not in dev_fields[5].split(","):
        raise _InnerError("/dev root is still writable after setup")
    assertions["dev-root-readonly"] = "pass"
def _assert_mounts(config: dict[str, Any], assertions: dict[str, str]) -> None:
    info = _mountinfo()
    binary = config["binary"]
    target = f"{P0_ROOT}/bin/{binary['target_name']}"
    mount_line = None
    proc_line = None
    masks: dict[str, list[str]] = {}
    for fields in info:
        if fields[4] == target:
            mount_line = fields
        if fields[4] == "/proc":
            proc_line = fields
        if fields[4] in ("/home", "/root", "/tmp", "/var/tmp", "/sys"):
            masks[fields[4]] = fields
    if mount_line is None:
        raise _InnerError("trusted executable bind is missing from mountinfo")
    options = mount_line[5].split(",")
    if not {"ro", "nosuid", "nodev"} <= set(options):
        raise _InnerError(f"trusted executable mount options are wrong: {options}")
    assertions["mounts-binary-ro"] = "pass"

    fixture_target = config["fixture"]["target"]
    fixture_line = None
    for fields in info:
        if fields[4] == fixture_target:
            fixture_line = fields
            break
    if fixture_line is None:
        raise _InnerError("fixture bind is missing from mountinfo")
    fixture_options = fixture_line[5].split(",")
    if not {"rw", "nosuid", "nodev"} <= set(fixture_options):
        raise _InnerError(
            f"fixture mount options are wrong: {fixture_options}"
        )
    assertions["mounts-fixture-policy"] = "pass"

    stat_info = os.stat(target)
    if (stat_info.st_dev, stat_info.st_ino) != (binary["dev"], binary["ino"]):
        raise _InnerError("trusted executable dev/inode mismatch")
    assertions["mounts-binary-identity"] = "pass"
    if probe._sha256_file(Path(target)) != binary["sha256"]:
        raise _InnerError("trusted executable content hash mismatch")
    assertions["mounts-binary-hash"] = "pass"

    if proc_line is None:
        raise _InnerError("/proc mount missing")
    super_options = proc_line[proc_line.index("-") + 3].split(",")
    hidepid = any(
        option in ("hidepid=2", "hidepid=invisible") for option in super_options
    )
    if not hidepid or "subset=pid" not in super_options:
        raise _InnerError(f"/proc mount lacks hidepid/subset: {super_options}")
    assertions["proc-hidepid"] = "pass"

    for path in ("/home", "/root", "/tmp", "/var/tmp", "/sys"):
        fields = masks.get(path)
        if fields is None:
            raise _InnerError(f"mask mount missing for {path}")
        if fields[fields.index("-") + 1] != "tmpfs":
            raise _InnerError(f"mask for {path} is not tmpfs")
    assertions["masks-tmpfs"] = "pass"
    sys_fields = masks["/sys"]
    if "ro" not in sys_fields[5].split(","):
        raise _InnerError("/sys mask is not read-only")
    assertions["sys-read-only"] = "pass"


def _assert_ipc_shm(config: dict[str, Any], assertions: dict[str, str]) -> None:
    result = libc.shmat(config["canary"]["sysv_shmid"], None, 0)
    if result not in (None, _SHMAT_FAILED):
        libc.shmdt(ctypes.c_void_p(result))
        raise _InnerError("host SysV canary is attachable inside the namespace")
    assertions["ipc-sysv-foreign-denied"] = "pass"

    shmid = libc.shmget(0, 64, 0o600)
    if shmid < 0:
        raise _InnerError("private SysV control failed")
    address = libc.shmat(shmid, None, 0)
    if address in (None, _SHMAT_FAILED):
        raise _InnerError("private SysV attach failed")
    libc.shmdt(ctypes.c_void_p(address))
    libc.shmctl(shmid, 0, None)
    assertions["ipc-sysv-private-ok"] = "pass"

    if os.path.exists(config["canary"]["shm_path"]):
        raise _InnerError("host /dev/shm canary is visible inside the namespace")
    assertions["shm-canary-absent"] = "pass"
    probe_file = Path("/dev/shm/probe-private")
    probe_file.write_bytes(b"p0")
    if probe_file.read_bytes() != b"p0":
        raise _InnerError("private /dev/shm is not functional")
    probe_file.unlink()
    assertions["shm-private-ok"] = "pass"


def _assert_keyring(assertions: dict[str, str]) -> None:
    ring = libc.syscall(SYS_KEYCTL, KEYCTL_JOIN_SESSION_KEYRING, None, 0, 0, 0)
    if ring < 0:
        raise _InnerError("joining a fresh anonymous session keyring failed")
    buffer = ctypes.create_string_buffer(4096)
    count = libc.syscall(SYS_KEYCTL, KEYCTL_READ, ring, ctypes.byref(buffer), 4096, 0)
    if count != 0:
        raise _InnerError("fresh session keyring carries inherited payload")
    assertions["keyring-fresh-empty"] = "pass"


def _start_provider(assertions: dict[str, str]) -> probe.FakeAnthropicProvider:
    provider = probe.FakeAnthropicProvider().start()
    port = int(provider.base_url.rsplit(":", 1)[1])
    connection = http.client.HTTPConnection("127.0.0.1", port, timeout=3)
    connection.request("GET", "/healthz")
    response = connection.getresponse()
    response.read()
    connection.close()
    if response.status != 200:
        raise _InnerError("in-namespace fake provider is unreachable")
    assertions["provider-loopback-ok"] = "pass"
    return provider


# -------------------------------------------------------------- phase: spawn


def _native_env(config: dict[str, Any], base_url: str) -> dict[str, str]:
    target = config["fixture"]["target"]
    return {
        "HOME": f"{target}/home",
        "XDG_CONFIG_HOME": f"{target}/xdg/config",
        "XDG_STATE_HOME": f"{target}/xdg/state",
        "XDG_CACHE_HOME": f"{target}/xdg/cache",
        "XDG_DATA_HOME": f"{target}/xdg/data",
        "XDG_RUNTIME_DIR": f"{target}/runtime",
        "CLAUDE_CONFIG_DIR": f"{target}/claude-config",
        "PATH": "/usr/bin:/bin",
        "TERM": "xterm-256color",
        "LANG": "C.UTF-8",
        "DISABLE_AUTOUPDATER": "1",
        "ANTHROPIC_BASE_URL": base_url,
        "ANTHROPIC_AUTH_TOKEN": probe.DUMMY_TOKEN,
    }


def _child_rlimits(run: dict[str, Any]) -> dict[int, int]:
    return {
        resource.RLIMIT_CORE: 0,
        resource.RLIMIT_NOFILE: run["nofile"],
        resource.RLIMIT_FSIZE: run["fsize_bytes"],
        resource.RLIMIT_CPU: run["cpu_seconds"],
        resource.RLIMIT_AS: run["as_bytes"],
    }


@contextlib.contextmanager
def _rlimit_bracket(limits: dict[int, int]) -> Iterator[None]:
    """Temporarily lower soft limits (hard limits untouched), then restore.

    The child spawned inside the bracket inherits the lowered soft limits;
    the reporter's saved (soft, hard) pairs are restored verbatim, so no
    unrecoverable hard-limit reduction ever happens.
    """

    saved: dict[int, tuple[int, int]] = {}
    try:
        for resource_id, soft in limits.items():
            saved_soft, saved_hard = resource.getrlimit(resource_id)
            saved[resource_id] = (saved_soft, saved_hard)
            if saved_hard == resource.RLIM_INFINITY:
                new_soft = soft
            else:
                new_soft = min(soft, saved_hard)
            resource.setrlimit(resource_id, (new_soft, saved_hard))
        yield
    finally:
        for resource_id, (saved_soft, saved_hard) in saved.items():
            resource.setrlimit(resource_id, (saved_soft, saved_hard))


def _capture(stream: Any, box: dict[str, Any], key: str) -> None:
    """Drain a stream; retain a bounded tail plus total count and hash."""

    tail = bytearray()
    digest = hashlib.sha256()
    total = 0
    while True:
        try:
            chunk = stream.read(4096)
        except (OSError, ValueError):
            break
        if not chunk:
            break
        digest.update(chunk)
        total += len(chunk)
        if len(tail) < _STDIO_CAP:
            tail += chunk[: _STDIO_CAP - len(tail)]
    box[key] = {
        "tail": bytes(tail),
        "bytes": total,
        "sha256": digest.hexdigest(),
        "truncated": total > len(tail),
    }


def _phase_spawn(
    config: dict[str, Any], provider: probe.FakeAnthropicProvider
) -> dict[str, Any]:
    run_cfg = config["run"]
    binary = config["binary"]
    command = [f"{P0_ROOT}/bin/{binary['target_name']}", *[str(a) for a in run_cfg["args"]]]
    env = _native_env(config, provider.base_url)
    cwd = f"{config['fixture']['target']}/home"
    use_pty = bool(run_cfg.get("use_pty"))
    master = slave = None
    if use_pty:
        master, slave = pty.openpty()
        stdin: Any = slave
        stdout_target: Any = slave
        stderr_target: Any = slave
    else:
        stdin = os.open("/dev/null", os.O_RDONLY)
        stdout_target = subprocess.PIPE
        stderr_target = subprocess.PIPE

    # Thread-safe rlimit bracketing: the reporter temporarily lowers its own
    # soft limits (hard limits untouched and restored verbatim), the child
    # inherits them at spawn, and no post-fork code runs in the child while
    # the provider thread is alive.
    try:
        with _rlimit_bracket(_child_rlimits(run_cfg)):
            process = subprocess.Popen(
                command,
                env=env,
                cwd=cwd,
                stdin=stdin,
                stdout=stdout_target,
                stderr=stderr_target,
                close_fds=True,
                start_new_session=True,
            )
    finally:
        if use_pty:
            if slave is not None:
                os.close(slave)
        else:
            os.close(stdin)

    box: dict[str, Any] = {}
    threads = []
    if use_pty:
        threads.append(
            threading.Thread(
                target=_capture,
                args=(os.fdopen(master, "rb", buffering=0), box, "pty"),
                daemon=True,
            )
        )
    else:
        threads.append(
            threading.Thread(
                target=_capture, args=(process.stdout, box, "stdout"), daemon=True
            )
        )
        threads.append(
            threading.Thread(
                target=_capture, args=(process.stderr, box, "stderr"), daemon=True
            )
        )
    for thread in threads:
        thread.start()

    timed_out = False
    try:
        process.wait(timeout=run_cfg["timeout"])
        returncode: int | None = process.returncode
    except subprocess.TimeoutExpired:
        timed_out = True
        try:
            os.killpg(process.pid, signal.SIGKILL)
        except (ProcessLookupError, PermissionError):
            pass
        process.wait()
        returncode = None
    for thread in threads:
        thread.join(timeout=10)

    # Reap every descendant so no zombie survives the reporter.
    while True:
        try:
            pid, _status = os.waitpid(-1, os.WNOHANG)
        except ChildProcessError:
            break
        if pid == 0:
            break

    stdout_meta = box.get("stdout", box.get("pty", {"tail": b"", "bytes": 0, "sha256": strict_json.sha256_hex(b""), "truncated": False}))
    stderr_meta = box.get("stderr", {"tail": b"", "bytes": 0, "sha256": strict_json.sha256_hex(b""), "truncated": False})
    argv_joined = "\n".join(command).encode("utf-8")
    return {
        "argv": command,
        "argv_count": len(command),
        "argv_sha256": strict_json.sha256_hex(argv_joined),
        "returncode": returncode,
        "timed_out": timed_out,
        "stdout": stdout_meta["tail"][-_REPORT_TAIL:].decode("utf-8", "replace"),
        "stdout_bytes": stdout_meta["bytes"],
        "stdout_sha256": stdout_meta["sha256"],
        "stdout_truncated": stdout_meta["truncated"],
        "stderr": stderr_meta["tail"][-_REPORT_TAIL:].decode("utf-8", "replace"),
        "stderr_bytes": stderr_meta["bytes"],
        "stderr_sha256": stderr_meta["sha256"],
        "stderr_truncated": stderr_meta["truncated"],
    }


# -------------------------------------------------------------------- main


def _write_report(fd: int, data: bytes) -> None:
    """Fully write the single bounded report; zero-progress is fail-closed."""

    view = memoryview(data)
    while view:
        try:
            written = os.write(fd, view)
        except OSError as exc:
            raise _InnerError(f"report write failed: {exc}")
        if written == 0:
            raise _InnerError("report write returned 0")
        view = view[written:]


def _fail(message: str) -> int:
    print(f"p0inner: {message}"[:800], file=sys.stderr)
    return 2


def main() -> int:
    try:
        control_fd = int(os.environ["P0_CONTROL_FD"])
        report_fd = int(os.environ["P0_REPORT_FD"])
    except (KeyError, ValueError):
        return _fail("control/report FD environment is missing")
    _set_dumpable_off()
    try:
        config, nonce = _read_control(control_fd)
    except _InnerError as exc:
        return _fail(str(exc))
    os.set_inheritable(report_fd, False)

    assertions: dict[str, str] = {}
    provider: probe.FakeAnthropicProvider | None = None
    try:
        if config.get("fault_injection"):
            # Test-only hook (ora-27): force a representative assertion
            # failure with no report written.
            raise _InnerError(f"fault injection: {config['fault_injection']}")
        _phase_mounts(config)
        namespaces = _phase_identity(config, assertions)
        _assert_canaries(config, assertions)
        _assert_dev(assertions)
        _assert_mounts(config, assertions)
        _assert_ipc_shm(config, assertions)
        _assert_keyring(assertions)
        provider = _start_provider(assertions)
        run = _phase_spawn(config, provider)
    except _InnerError as exc:
        return _fail(str(exc))
    except (OSError, subprocess.CalledProcessError) as exc:
        return _fail(f"setup failure: {exc}")
    finally:
        if provider is not None:
            provider.stop()

    report = {
        "schema": "p0-report/1",
        "nonce": nonce,
        "namespaces": namespaces,
        "hostname": socket.gethostname(),
        "groups": os.getgroups(),
        "assertions": assertions,
        "run": run,
        "requests": [
            {
                "method": record.method,
                "path": record.path,
                "model": record.model,
                "tool_names": list(record.tool_names),
                "has_system": record.has_system,
                "auth": record.auth,
                "body_sha256": record.body_sha256,
            }
            for record in (provider.requests if provider is not None else ())
        ],
        "requests_dropped": provider.dropped_requests if provider is not None else 0,
        "keyring": {"payload_keys": 0},
        "residuals": [
            f"supplementary groups: {_SUPPLEMENTARY_NOTE}",
        ],
    }
    data = strict_json.canonical_file_bytes(report)
    if len(data) > 32 * 1024:
        return _fail("report exceeds its bounded size")
    try:
        _write_report(report_fd, data)
    except _InnerError as exc:
        return _fail(str(exc))
    finally:
        os.close(report_fd)
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
