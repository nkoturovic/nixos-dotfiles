"""Tests for the P0 namespace isolation mechanism (ora-24).

Unit tests cover construction, refusals, parsers, canaries, report
validation, watchdog/tamper/no-evidence paths, and CLI gating without
spawning namespaces. Namespace self-tests run the real mechanism against
harmless fake executables only — never the installed Claude binary, never a
real provider, never the live daemon — and skip only on genuinely
unsupported kernel features.
"""

from __future__ import annotations

import contextlib
import ctypes
import hashlib
import io
import json
import os
import resource
import secrets
import shutil
import signal
import socket
import stat
import subprocess
import sys
import tempfile
import unittest
from pathlib import Path
from unittest import mock

from claude_multi import p0, p0inner, probe, state, strict_json
from claude_multi.probe import ProbeError


_SH_FAKE = (
    "#!/bin/sh\n"
    "echo P0-FAKE-OK\n"
    'echo "HOME=$HOME"\n'
    'if [ -w "$0" ]; then echo BINARY-WRITABLE; else echo BINARY-READONLY; fi\n'
)
_SH_SLEEP = "#!/bin/sh\nsleep 30 &\nwait\n"
_SH_TTY = "#!/bin/sh\nif [ -t 0 ]; then echo P0-PTY-OK; else echo NO-TTY; fi\n"
_SENTINEL = "P0-SENTINEL-9f27c1-DO-NOT-LEAK"
_SENTINEL_BODY = (
    f"#!{sys.executable}\n"
    "import http.client\n"
    "import json\n"
    "import os\n"
    "import urllib.parse\n"
    "url = urllib.parse.urlsplit(os.environ['ANTHROPIC_BASE_URL'])\n"
    "body = json.dumps({'model': 'probe-model', 'max_tokens': 8, "
    "'messages': [{'role': 'user', 'content': '" + _SENTINEL + "'}]}).encode()\n"
    "conn = http.client.HTTPConnection(url.hostname, url.port, timeout=5)\n"
    "conn.request('POST', '/v1/messages', body=body, "
    "headers={'Content-Type': 'application/json', "
    "'x-api-key': os.environ['ANTHROPIC_AUTH_TOKEN']})\n"
    "resp = conn.getresponse()\n"
    "resp.read()\n"
    "print('STATUS=' + str(resp.status))\n"
)
_RLIMIT_BODY = (
    f"#!{sys.executable}\n"
    "import resource\n"
    "for name in ('CORE', 'NOFILE', 'FSIZE', 'CPU', 'AS'):\n"
    "    print(name, resource.getrlimit(getattr(resource, 'RLIMIT_' + name)))\n"
)

_EXPECTED_ASSERTIONS = (
    "identity-uid-gid",
    "identity-pid1",
    "identity-groups-fidelity",
    "namespaces-differ",
    "hostname-private",
    "routes-empty",
    "canary-tcp-refused",
    "canary-unix-refused",
    "host-paths-masked",
    "proc-net-lacks-host-port",
    "dev-exact-set",
    "dev-major-minor",
    "dev-root-readonly",
    "mounts-binary-ro",
    "mounts-binary-identity",
    "mounts-binary-hash",
    "mounts-fixture-policy",
    "proc-hidepid",
    "masks-tmpfs",
    "sys-read-only",
    "ipc-sysv-foreign-denied",
    "ipc-sysv-private-ok",
    "shm-canary-absent",
    "shm-private-ok",
    "keyring-fresh-empty",
    "provider-loopback-ok",
)


class P0TestCase(unittest.TestCase):
    def setUp(self) -> None:
        self.root = Path(tempfile.mkdtemp(prefix="claude-multi-p0-test-"))
        os.chmod(self.root, 0o700)
        self.addCleanup(self._cleanup)
        self.environ = {"HOME": str(self.root / "live" / "home"), "PATH": "/usr/bin:/bin"}
        self.fixture_root = self.root / "fixture"

    def _cleanup(self) -> None:
        shutil.rmtree(self.root, ignore_errors=True)

    def _flags(self) -> dict:
        return {
            "allow-local-claude": True,
            "fixture-root": str(self.fixture_root),
        }

    def _fixture(self) -> probe.ProbeFixture:
        return probe.build_fixture(self.fixture_root, environ=self.environ)

    def _fake_script(self, body: str = _SH_FAKE, name: str = "fake-claude") -> Path:
        stage = state.ensure_private_dir(self.fixture_root / "bin")
        script = stage / name
        state.atomic_write(script, body.encode("utf-8"))
        os.chmod(script, 0o700)
        return script

    def _trusted(
        self, script: Path, *, fake: bool = True, digest: str | None = None
    ) -> probe.TrustedExecutable:
        return probe.TrustedExecutable(
            script,
            digest
            if digest is not None
            else hashlib.sha256(script.read_bytes()).hexdigest(),
            fake=fake,
        )

    def _contract_file(self, script: Path, *, digest: str | None = None) -> Path:
        contract = {
            "claude": {
                "executable": {
                    "resolved_path": str(script),
                    "sha256": digest
                    if digest is not None
                    else hashlib.sha256(script.read_bytes()).hexdigest(),
                }
            }
        }
        path = self.root / "native-contract.json"
        path.write_bytes(strict_json.canonical_file_bytes(contract))
        return path


class PreflightTests(P0TestCase):
    def test_resolve_binaries_uses_ambient_path(self) -> None:
        environ = {"PATH": "/nix/store/aaa/bin:/nix/store/bbb/bin"}
        resolved = p0.resolve_binaries(
            environ,
            which=lambda name, path=None: f"/nix/store/aaa/bin/{name}"
            if name == "unshare"
            else f"/nix/store/bbb/bin/{name}",
        )
        self.assertEqual(resolved["unshare"], "/nix/store/aaa/bin/unshare")
        self.assertEqual(resolved["ip"], "/nix/store/bbb/bin/ip")

    def test_resolve_binaries_missing_tool_unsupported(self) -> None:
        with self.assertRaisesRegex(p0.P0Unsupported, "ip"):
            p0.resolve_binaries(
                {"PATH": "/empty"},
                which=lambda name, path=None: "/x/unshare"
                if name == "unshare"
                else None,
            )

    def test_resolve_binaries_never_requires_mount_or_keyctl(self) -> None:
        # mount/keyctl operations use raw syscalls; those binaries are not
        # part of the required set.
        resolved = p0.resolve_binaries(
            {"PATH": "/x"},
            which=lambda name, path=None: f"/x/{name}",
        )
        self.assertEqual(sorted(resolved), ["ip", "unshare"])

    def test_userns_probe_uses_resolved_path_and_full_namespaces(self) -> None:
        captured: dict = {}
        completed = subprocess.CompletedProcess(args=[], returncode=0)

        def runner(argv, **_k):
            captured["argv"] = argv
            return completed

        p0.probe_userns_feature("/resolved/unshare", runner=runner)
        argv = captured["argv"]
        self.assertEqual(argv[0], "/resolved/unshare")
        for flag in (
            "--user",
            "--map-root-user",
            "--mount",
            "--net",
            "--pid",
            "--uts",
            "--ipc",
            "--fork",
            "--kill-child=SIGKILL",
        ):
            self.assertIn(flag, argv)
        # The probe payload is the absolute current interpreter, never an
        # ambient-PATH tool.
        self.assertEqual(argv[-3:], [sys.executable, "-c", "pass"])

    def test_userns_probe_oserror_classified_unsupported(self) -> None:
        def runner(*_a, **_k):
            raise FileNotFoundError("unshare gone")

        with self.assertRaisesRegex(p0.P0Unsupported, "cannot run"):
            p0.probe_userns_feature("/gone/unshare", runner=runner)

    def test_userns_probe_failure_unsupported(self) -> None:
        completed = subprocess.CompletedProcess(args=[], returncode=1)
        with self.assertRaisesRegex(p0.P0Unsupported, "unavailable"):
            p0.probe_userns_feature("/x/unshare", runner=lambda *a, **k: completed)

    def test_non_x86_64_unsupported(self) -> None:
        with self.assertRaisesRegex(p0.P0Unsupported, "x86_64"):
            p0.preflight(machine="aarch64")

    def test_parse_proc_keys_structural_ok(self) -> None:
        text = (
            "11111111 I--Q---     1 perm 1f3f0000  1000 65534 keyring   _uid_ses.1000: 1\n"
            "22222222 I--Q---     4 perm 1f3f0000  1000 65534 keyring   _uid.1000: empty\n"
            "33333333 I--Q---     8 perm 3f030000  1000  1000 keyring   _ses: 1\n"
        )
        p0.parse_proc_keys(text, 1000)

    def test_parse_proc_keys_payload_blocks(self) -> None:
        text = (
            "44444444 I--Q---     1 perm 3f030000  1000  1000 user      some-payload\n"
        )
        with self.assertRaisesRegex(ProbeError, "payload key"):
            p0.parse_proc_keys(text, 1000)

    def test_parse_proc_keys_named_ring_blocks(self) -> None:
        text = (
            "55555555 I--Q---     1 perm 3f030000  1000  1000 keyring   _persistent.1000: empty\n"
        )
        with self.assertRaisesRegex(ProbeError, "non-structural keyring"):
            p0.parse_proc_keys(text, 1000)

    def test_parse_proc_keys_non_empty_uid_ring_blocks(self) -> None:
        text = (
            "66666666 I--Q---     2 perm 1f3f0000  1000 65534 keyring   _uid.1000: 2\n"
        )
        with self.assertRaisesRegex(ProbeError, "not empty"):
            p0.parse_proc_keys(text, 1000)

    def test_parse_proc_keys_unparseable_blocks(self) -> None:
        with self.assertRaisesRegex(ProbeError, "unparseable"):
            p0.parse_proc_keys("too few fields\n", 1000)

    def test_parse_proc_keys_live_host(self) -> None:
        # Hermetic: pass when the host keyring domain is clean/structural,
        # skip with an explicit reason on unsupported dirty hosts.
        try:
            p0.parse_proc_keys(
                Path("/proc/keys").read_text(errors="replace"), os.getuid()
            )
        except ProbeError as exc:
            self.skipTest(f"host keyring domain is not clean/structural: {exc}")

    def test_preflight_live_host(self) -> None:
        try:
            info = p0.preflight()
        except p0.P0Unsupported as exc:
            self.skipTest(f"P0 unsupported on this host: {exc}")
        except ProbeError as exc:
            self.skipTest(f"host keyring domain is not clean/structural: {exc}")
        self.assertEqual(info.payload_keys, 0)
        self.assertEqual(info.uid, os.getuid())
        self.assertEqual(info.gid, os.getgid())
        for name in ("user", "mnt", "net", "pid", "uts", "ipc"):
            self.assertEqual(info.namespaces[name], os.readlink(f"/proc/self/ns/{name}"))
        self.assertTrue(Path(info.binaries["unshare"]).is_absolute())
        self.assertTrue(Path(info.binaries["ip"]).is_absolute())


class ConstructionTests(P0TestCase):
    def test_build_unshare_argv_exact_with_resolved_path(self) -> None:
        self.assertEqual(
            p0.build_unshare_argv("/resolved/unshare"),
            [
                "/resolved/unshare",
                "--user",
                "--map-root-user",
                "--mount",
                "--net",
                "--pid",
                "--uts",
                "--ipc",
                "--fork",
                "--kill-child=SIGKILL",
                "--",
                sys.executable,
                "-m",
                "claude_multi.p0inner",
            ],
        )

    def test_build_inner_env_minimal_and_credential_free(self) -> None:
        env = p0.build_inner_env("run-id-1")
        self.assertEqual(env["PATH"], "/usr/bin:/bin")
        self.assertEqual(env["P0_RUN_ID"], "run-id-1")
        self.assertTrue((Path(env["PYTHONPATH"]) / "claude_multi" / "p0inner.py").is_file())
        for name in env:
            self.assertNotIn("TOKEN", name)
            self.assertNotIn("KEY", name)

    def test_build_control_config_shape(self) -> None:
        fixture = self._fixture()
        info = p0.Preflight(
            uid=os.getuid(),
            gid=os.getgid(),
            hostname="host",
            namespaces={n: f"{n}:[1]" for n in ("user", "mnt", "net", "pid", "uts", "ipc")},
            payload_keys=0,
            binaries={"unshare": "/x/unshare", "ip": "/x/ip"},
        )
        script = self._fake_script()
        trusted = self._trusted(script)
        with p0.Canaries(secrets.token_hex(8)) as canaries:
            config = p0.build_control_config(
                preflight_info=info,
                canaries=canaries,
                trusted=trusted,
                executable_info=os.stat(script),
                fixture=fixture,
                args=("--version",),
                timeout=42.0,
                use_pty=True,
            )
        # The capability nonce travels only as the second control line.
        self.assertNotIn("nonce", config)
        self.assertEqual(config["binaries"]["ip"], "/x/ip")
        self.assertEqual(config["uid"], os.getuid())
        self.assertEqual(config["binary"]["target_name"], "fake-claude")
        self.assertEqual(config["binary"]["sha256"], trusted.sha256)
        self.assertEqual(config["fixture"]["source"], str(fixture.root))
        self.assertEqual(config["fixture"]["target"], "/run/claude-multi-p0/fixture")
        self.assertNotIn("fault_injection", config)
        run = config["run"]
        self.assertEqual(run["args"], ["--version"])
        self.assertEqual(run["timeout"], 42.0)
        self.assertEqual(run["cpu_seconds"], 72)
        self.assertEqual(run["nofile"], 256)
        self.assertEqual(run["fsize_bytes"], 16 * 1024 * 1024)
        self.assertTrue(run["use_pty"])

    def test_build_control_config_fault_injection_opt_in(self) -> None:
        fixture = self._fixture()
        info = p0.Preflight(
            uid=1,
            gid=1,
            hostname="h",
            namespaces={},
            payload_keys=0,
            binaries={"unshare": "/x/u", "ip": "/x/i"},
        )
        script = self._fake_script()
        with p0.Canaries(secrets.token_hex(8)) as canaries:
            config = p0.build_control_config(
                preflight_info=info,
                canaries=canaries,
                trusted=self._trusted(script),
                executable_info=os.stat(script),
                fixture=fixture,
                args=(),
                timeout=1.0,
                use_pty=False,
                fault_injection="assert-dev",
            )
        self.assertEqual(config["fault_injection"], "assert-dev")


class HelperTests(P0TestCase):
    def test_write_all_completes_partial_writes(self) -> None:
        read_fd, write_fd = os.pipe()
        payload = b"x" * 10000
        real_write = os.write

        def partial(fd, data):
            return real_write(fd, bytes(data[:7]))

        with mock.patch("os.write", side_effect=partial):
            p0._write_all(write_fd, payload, "test")
        os.close(write_fd)
        received = b""
        while len(received) < len(payload):
            received += os.read(read_fd, len(payload) - len(received))
        os.close(read_fd)
        self.assertEqual(received, payload)

    def test_write_all_broken_pipe_taxonomy(self) -> None:
        read_fd, write_fd = os.pipe()
        os.close(read_fd)
        with self.assertRaisesRegex(ProbeError, "closed the control channel"):
            p0._write_all(write_fd, b"data", "control configuration")
        os.close(write_fd)

    def test_write_all_size_cap(self) -> None:
        with self.assertRaisesRegex(ProbeError, "bound"):
            p0._write_all(0, b"x" * (p0._CONTROL_CAP + 1), "control configuration")

    def test_mountinfo_holder_exact_and_component_prefix(self) -> None:
        line = "679 678 0:41 /fixture /run/claude-multi-p0/fixture rw - tmpfs tmpfs rw\n"
        self.assertTrue(p0._mountinfo_holds_marker(line, "/fixture"))
        self.assertTrue(p0._mountinfo_holds_marker(line, "/run/claude-multi-p0/fixture"))
        self.assertFalse(p0._mountinfo_holds_marker(line, "/fix"))
        self.assertFalse(p0._mountinfo_holds_marker(line, "/fixture2"))

    def test_mountinfo_holder_unescapes_fields(self) -> None:
        line = "679 678 0:41 /tmp/my\\040dir/fixture /run/x rw - tmpfs tmpfs rw\n"
        self.assertTrue(p0._mountinfo_holds_marker(line, "/tmp/my dir/fixture"))
        self.assertFalse(p0._mountinfo_holds_marker(line, "/tmp/my"))

    def test_rlimit_bracket_applies_and_restores(self) -> None:
        saved_soft, saved_hard = resource.getrlimit(resource.RLIMIT_NOFILE)
        target = max(64, saved_soft - 1) if saved_soft > 64 else saved_soft
        with p0inner._rlimit_bracket({resource.RLIMIT_NOFILE: target}):
            soft, hard = resource.getrlimit(resource.RLIMIT_NOFILE)
            self.assertEqual(soft, min(target, saved_hard))
            self.assertEqual(hard, saved_hard)
        self.assertEqual(
            resource.getrlimit(resource.RLIMIT_NOFILE), (saved_soft, saved_hard)
        )

    def test_shmat_typed_pointer_success_and_failure(self) -> None:
        shmid = p0inner.libc.shmget(0, 64, 0o600)
        self.assertGreaterEqual(shmid, 0)
        address = p0inner.libc.shmat(shmid, None, 0)
        self.assertNotIn(address, (None, p0inner._SHMAT_FAILED))
        self.assertGreater(address, 0)
        self.assertEqual(p0inner.libc.shmdt(ctypes.c_void_p(address)), 0)
        bogus = p0inner.libc.shmat(0x7FFFFFFE, None, 0)
        self.assertIn(bogus, (None, p0inner._SHMAT_FAILED))
        p0inner.libc.shmctl(shmid, 0, None)  # IPC_RMID

    def test_write_report_zero_progress_fails_closed(self) -> None:
        read_fd, write_fd = os.pipe()
        try:
            with mock.patch.object(p0inner.os, "write", return_value=0):
                with self.assertRaisesRegex(p0inner._InnerError, "returned 0"):
                    p0inner._write_report(write_fd, b"data")
        finally:
            os.close(write_fd)
            os.close(read_fd)

    def test_write_report_completes_partial_writes(self) -> None:
        read_fd, write_fd = os.pipe()
        payload = b"x" * 100
        real_write = os.write

        def partial(fd, data):
            return real_write(fd, bytes(data[:7]))

        try:
            with mock.patch.object(p0inner.os, "write", side_effect=partial):
                p0inner._write_report(write_fd, payload)
            os.close(write_fd)
            received = os.read(read_fd, len(payload))
        finally:
            os.close(read_fd)
        self.assertEqual(received, payload)

    def test_write_report_broken_pipe_fails_closed(self) -> None:
        read_fd, write_fd = os.pipe()
        os.close(read_fd)
        try:
            with self.assertRaisesRegex(p0inner._InnerError, "report write failed"):
                p0inner._write_report(write_fd, b"data")
        finally:
            os.close(write_fd)


class ReportValidationTests(P0TestCase):
    def _valid(self, nonce: str) -> bytes:
        return strict_json.canonical_file_bytes(
            {
                "schema": "p0-report/1",
                "nonce": nonce,
                "assertions": {"identity-pid1": "pass"},
                "run": {"returncode": 0},
            }
        )

    def test_valid_report_accepted(self) -> None:
        document = p0.validate_report(self._valid("abc"), "abc")
        self.assertEqual(document["run"]["returncode"], 0)

    def test_nonce_mismatch_rejected(self) -> None:
        with self.assertRaisesRegex(ProbeError, "nonce"):
            p0.validate_report(self._valid("abc"), "xyz")

    def test_schema_mismatch_rejected(self) -> None:
        raw = strict_json.canonical_file_bytes(
            {"schema": "other", "nonce": "abc", "assertions": {"a": "pass"}}
        )
        with self.assertRaisesRegex(ProbeError, "schema"):
            p0.validate_report(raw, "abc")

    def test_failed_assertion_rejected(self) -> None:
        raw = strict_json.canonical_file_bytes(
            {
                "schema": "p0-report/1",
                "nonce": "abc",
                "assertions": {"dev-exact-set": "fail"},
            }
        )
        with self.assertRaisesRegex(ProbeError, "dev-exact-set"):
            p0.validate_report(raw, "abc")

    def test_empty_and_oversize_rejected(self) -> None:
        with self.assertRaisesRegex(ProbeError, "missing or exceeds"):
            p0.validate_report(b"", "abc")
        with self.assertRaisesRegex(ProbeError, "missing or exceeds"):
            p0.validate_report(self._valid("abc"), "abc", oversize=True)

    def test_non_json_rejected(self) -> None:
        with self.assertRaisesRegex(ProbeError, "strict JSON"):
            p0.validate_report(b"{not json", "abc")

    def test_read_capped_flags_oversize(self) -> None:
        read_fd, write_fd = os.pipe()
        os.write(write_fd, b"x" * 10000)
        os.close(write_fd)
        data, oversize = p0._read_capped(read_fd, 4096)
        os.close(read_fd)
        self.assertTrue(oversize)
        self.assertEqual(len(data), 4096)


class CanaryTests(P0TestCase):
    def test_zero_contact_verify_and_close(self) -> None:
        with p0.Canaries(secrets.token_hex(8)) as canaries:
            result = canaries.verify()
            self.assertEqual(result["tcp_contacts"], 0)
            self.assertEqual(result["unix_contacts"], 0)
            self.assertTrue(result["shm_intact"])
            self.assertTrue(result["sysv_intact"])
            shm_path, unix_path = canaries.shm_path, canaries.unix_path
        self.assertFalse(shm_path.exists())
        self.assertFalse(unix_path.exists())

    def test_tcp_contact_detected(self) -> None:
        with p0.Canaries(secrets.token_hex(8)) as canaries:
            connection = socket.create_connection(
                ("127.0.0.1", canaries.tcp_port), timeout=2
            )
            connection.close()
            with self.assertRaisesRegex(ProbeError, "contact"):
                canaries.verify()

    def test_unix_contact_detected(self) -> None:
        with p0.Canaries(secrets.token_hex(8)) as canaries:
            client = socket.socket(socket.AF_UNIX, socket.SOCK_STREAM)
            client.connect(str(canaries.unix_path))
            client.close()
            with self.assertRaisesRegex(ProbeError, "contact"):
                canaries.verify()

    def test_shm_tamper_detected(self) -> None:
        with p0.Canaries(secrets.token_hex(8)) as canaries:
            canaries.shm_path.write_bytes(b"tampered")
            with self.assertRaisesRegex(ProbeError, "shm"):
                canaries.verify()

    def test_sysv_segment_removed_on_close(self) -> None:
        canaries = p0.Canaries(secrets.token_hex(8))
        shmid = canaries.sysv_shmid
        canaries.close()
        status = ctypes.create_string_buffer(256)
        self.assertEqual(canaries._libc.shmctl(shmid, 2, status), -1)  # IPC_STAT

    def test_unix_stage_failure_cleans_tcp(self) -> None:
        tcp_sock = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
        with mock.patch.object(
            p0.socket, "socket", side_effect=[tcp_sock, OSError("boom")]
        ):
            with self.assertRaisesRegex(OSError, "boom"):
                p0.Canaries("injunix")
        self.assertEqual(tcp_sock.fileno(), -1)
        self.assertFalse(Path("/tmp/cm-p0-canary-injunix.sock").exists())
        self.assertFalse(Path("/dev/shm/cm-p0-canary-injunix").exists())

    def test_shm_stage_failure_cleans_listeners_and_unix_file(self) -> None:
        with mock.patch.object(Path, "write_bytes", side_effect=OSError("boom")):
            with self.assertRaisesRegex(OSError, "boom"):
                p0.Canaries("injshm")
        self.assertFalse(Path("/tmp/cm-p0-canary-injshm.sock").exists())
        self.assertFalse(Path("/dev/shm/cm-p0-canary-injshm").exists())

    def test_sysv_stage_failure_cleans_all(self) -> None:
        fake_libc = mock.Mock()
        fake_libc.shmget.return_value = -1
        with mock.patch.object(p0.ctypes, "CDLL", return_value=fake_libc):
            with self.assertRaisesRegex(ProbeError, "SysV canary"):
                p0.Canaries("injsysv")
        self.assertFalse(Path("/tmp/cm-p0-canary-injsysv.sock").exists())
        self.assertFalse(Path("/dev/shm/cm-p0-canary-injsysv").exists())

    def test_unix_bind_failure_cleans_socket_file(self) -> None:
        # The socket path is assigned before the fallible bind, so cleanup
        # unlinks even when bind fails after the file exists.
        path = Path("/tmp/cm-p0-canary-injbind.sock")
        path.write_bytes(b"stale")
        with self.assertRaises(OSError):
            p0.Canaries("injbind")
        self.assertFalse(path.exists())
        self.assertFalse(Path("/dev/shm/cm-p0-canary-injbind").exists())

    def test_shm_write_failure_cleans_partial_file(self) -> None:
        path = Path("/dev/shm/cm-p0-canary-injwr")
        real_write = Path.write_bytes

        def flaky(self_path, data):
            if self_path == path:
                real_write(self_path, b"partial")
                raise OSError("boom")
            return real_write(self_path, data)

        with mock.patch.object(Path, "write_bytes", flaky):
            with self.assertRaisesRegex(OSError, "boom"):
                p0.Canaries("injwr")
        self.assertFalse(path.exists())
        self.assertFalse(Path("/tmp/cm-p0-canary-injwr.sock").exists())


class _FakeWatchdogProcess:
    """Popen double: times out once, then dies after the group kill."""

    def __init__(self) -> None:
        self.pid = 16777215  # no such process group on the host
        self.returncode: int | None = None
        self._calls = 0

    def communicate(self, timeout: float | None = None):
        self._calls += 1
        if self._calls == 1:
            raise subprocess.TimeoutExpired(cmd="unshare", timeout=timeout or 0)
        self.returncode = -signal.SIGKILL
        return "", ""

    def poll(self):
        return self.returncode

    def wait(self, timeout: float | None = None):
        return self.returncode


class _FakeDStateProcess:
    """Popen double: never reaps, simulating an unkillable D-state child."""

    def __init__(self) -> None:
        self.pid = 16777214  # no such process group on the host
        self.returncode: int | None = None

    def communicate(self, timeout: float | None = None):
        raise subprocess.TimeoutExpired(cmd="unshare", timeout=timeout or 0)

    def poll(self):
        return None

    def wait(self, timeout: float | None = None):
        return None


class RunP0RefusalTests(P0TestCase):
    def test_real_spec_requires_allow_real(self) -> None:
        fixture = self._fixture()
        script = self._fake_script()
        trusted = self._trusted(script, fake=False)

        def forbidden_popen(*_a, **_k):
            raise AssertionError("popen must not run")

        with self.assertRaisesRegex(ProbeError, "--allow-real-execution"):
            p0.run_p0(
                trusted=trusted,
                fixture=fixture,
                popen=forbidden_popen,
            )

    def test_timeout_must_be_finite_and_positive(self) -> None:
        fixture = self._fixture()
        script = self._fake_script()
        for bad in (0, -1.0, float("inf"), float("nan")):
            with self.subTest(timeout=bad):
                with self.assertRaisesRegex(ProbeError, "finite|positive"):
                    p0.run_p0(
                        trusted=self._trusted(script), fixture=fixture, timeout=bad
                    )

    def test_parent_timeout_must_be_finite_and_positive(self) -> None:
        fixture = self._fixture()
        script = self._fake_script()
        for bad in (0, -1.0, float("inf"), float("nan")):
            with self.subTest(parent_timeout=bad):
                with self.assertRaisesRegex(ProbeError, "parent timeout"):
                    p0.run_p0(
                        trusted=self._trusted(script),
                        fixture=fixture,
                        parent_timeout=bad,
                    )

    def test_cli_allow_real_empty_value_counts_as_presence(self) -> None:
        script = self._fake_script()
        flags = {
            **self._flags(),
            "native-contract": str(self._contract_file(script, digest="0" * 64)),
            "p0": True,
            "allow-real-execution": "",  # presence-based consent, empty value
        }
        stderr = io.StringIO()
        with contextlib.redirect_stderr(stderr):
            code = probe.probe_cli(["run"], flags, [], environ=self.environ)
        self.assertEqual(code, 2)
        # Presence consent was accepted: the failure is the hash gate that
        # runs after the flag gate, not the flag gate itself.
        self.assertIn("hash", stderr.getvalue())
        self.assertNotIn("--allow-real-execution", stderr.getvalue())

    def test_watchdog_dstate_fails_closed(self) -> None:
        fixture = self._fixture()
        script = self._fake_script()
        process = _FakeDStateProcess()
        kills: list[tuple[int, int]] = []
        with self.assertRaisesRegex(ProbeError, "did not reap"):
            p0.run_p0(
                trusted=self._trusted(script),
                fixture=fixture,
                timeout=1.0,
                evidence_name="p0-dstate",
                popen=lambda *a, **k: process,
                kill_group=lambda pgid, sig: kills.append((pgid, sig)),
            )
        self.assertIn((process.pid, signal.SIGKILL), kills)
        self.assertFalse((self.fixture_root / "evidence").exists())

    def test_tampered_binary_rejected_before_spawn(self) -> None:
        fixture = self._fixture()
        script = self._fake_script()
        trusted = self._trusted(script)
        state.atomic_write(script, b"#!/bin/sh\necho TAMPERED\n")
        os.chmod(script, 0o700)

        def forbidden_popen(*_a, **_k):
            raise AssertionError("popen must not run")

        with self.assertRaisesRegex(ProbeError, "hash"):
            p0.run_p0(trusted=trusted, fixture=fixture, popen=forbidden_popen)
        self.assertFalse((self.fixture_root / "evidence").exists())

    def test_watchdog_kills_group_and_writes_no_evidence(self) -> None:
        fixture = self._fixture()
        script = self._fake_script()
        process = _FakeWatchdogProcess()
        kills: list[tuple[int, int]] = []
        with self.assertRaisesRegex(ProbeError, "watchdog"):
            p0.run_p0(
                trusted=self._trusted(script),
                fixture=fixture,
                timeout=1.0,
                evidence_name="p0-watchdog",
                popen=lambda *a, **k: process,
                kill_group=lambda pgid, sig: kills.append((pgid, sig)),
            )
        self.assertEqual(kills, [(process.pid, signal.SIGKILL)])
        self.assertFalse((self.fixture_root / "evidence").exists())

    def test_cli_run_p0_requires_allow_real_for_real_spec(self) -> None:
        script = self._fake_script()
        flags = {
            **self._flags(),
            "native-contract": str(self._contract_file(script)),
            "p0": True,
        }
        stderr = io.StringIO()
        with contextlib.redirect_stderr(stderr):
            code = probe.probe_cli(["run"], flags, [], environ=self.environ)
        self.assertEqual(code, 2)
        self.assertIn("--allow-real-execution", stderr.getvalue())
        self.assertFalse((self.fixture_root / "evidence").exists())

    def test_cli_allow_real_without_p0_rejected(self) -> None:
        script = self._fake_script()
        flags = {
            **self._flags(),
            "native-contract": str(self._contract_file(script)),
            "allow-real-execution": True,
        }
        stderr = io.StringIO()
        with contextlib.redirect_stderr(stderr):
            code = probe.probe_cli(["run"], flags, [], environ=self.environ)
        self.assertEqual(code, 2)
        self.assertIn("only valid together with --p0", stderr.getvalue())

    def test_cli_p0_self_test_rejects_argv_tail(self) -> None:
        stderr = io.StringIO()
        with contextlib.redirect_stderr(stderr):
            code = probe.probe_cli(
                ["p0-self-test"], self._flags(), ["/bin/x"], environ=self.environ
            )
        self.assertEqual(code, 2)
        self.assertIn("no executable argv", stderr.getvalue())


class NamespaceSelfTests(P0TestCase):
    """Real namespace runs with harmless fake executables only."""

    def setUp(self) -> None:
        super().setUp()
        try:
            p0.preflight()
        except p0.P0Unsupported as exc:
            self.skipTest(f"P0 unsupported on this host: {exc}")
        self.fixture = self._fixture()

    def test_p0_namespace_run_passes_and_writes_evidence(self) -> None:
        script = self._fake_script()
        result = p0.run_p0(
            trusted=self._trusted(script),
            fixture=self.fixture,
            timeout=60.0,
            evidence_name="p0-test",
        )
        report = result.report
        for key in _EXPECTED_ASSERTIONS:
            with self.subTest(assertion=key):
                self.assertEqual(report["assertions"].get(key), "pass")
        for name in ("user", "mnt", "net", "pid", "uts", "ipc"):
            self.assertNotEqual(
                report["namespaces"][name], os.readlink(f"/proc/self/ns/{name}")
            )
        self.assertEqual(report["hostname"], "claude-multi-p0")
        self.assertEqual(report["keyring"]["payload_keys"], 0)
        self.assertEqual(result.run["returncode"], 0)
        self.assertFalse(result.run["timed_out"])
        self.assertIn("P0-FAKE-OK", result.run["stdout"])
        self.assertIn("BINARY-READONLY", result.run["stdout"])
        self.assertIn("HOME=/run/claude-multi-p0/fixture/home", result.run["stdout"])
        self.assertEqual(result.canaries["tcp_contacts"], 0)
        self.assertEqual(result.canaries["unix_contacts"], 0)

        evidence = strict_json.load(self.fixture_root / "evidence" / "p0-test.json")
        self.assertEqual(evidence["kind"], "p0-run")
        self.assertEqual(evidence["keyring"]["payload_keys"], 0)
        self.assertEqual(evidence["keyring"]["status"], "bounded")
        self.assertEqual(evidence["canaries"]["tcp_contacts"], 0)
        self.assertTrue(evidence["trusted"]["fake"])
        self.assertTrue(
            any("supplementary groups" in item for item in evidence["residuals"])
        )
        self.assertTrue(any("same-kuid" in item for item in evidence["residuals"]))
        # Metadata-only run evidence (ora-28): no raw stdio text, no argv.
        run_evidence = evidence["report"]["run"]
        self.assertNotIn("stdout", run_evidence)
        self.assertNotIn("stderr", run_evidence)
        self.assertNotIn("argv", run_evidence)
        self.assertEqual(run_evidence["returncode"], 0)
        self.assertGreater(run_evidence["stdout_bytes"], 0)
        self.assertTrue(run_evidence["stdout_sha256"])
        self.assertFalse(run_evidence["stdout_truncated"])
        # The raw capability nonce is validated in memory only; only its
        # hash persists.
        self.assertNotIn("nonce", evidence["report"])
        self.assertTrue(evidence["nonce_sha256"])
        raw = (self.fixture_root / "evidence" / "p0-test.json").read_bytes()
        self.assertNotIn(result.report["nonce"].encode(), raw)
        self.assertIn(evidence["nonce_sha256"].encode(), raw)
        self.assertNotIn(b"P0-FAKE-OK", raw)
        self.assertNotIn(b"BINARY-READONLY", raw)

    def test_p0_sentinel_prompt_never_reaches_evidence(self) -> None:
        script = self._fake_script(body=_SENTINEL_BODY)
        result = p0.run_p0(
            trusted=self._trusted(script),
            fixture=self.fixture,
            timeout=60.0,
            evidence_name="p0-sentinel",
        )
        expected_body = json.dumps(
            {
                "model": "probe-model",
                "max_tokens": 8,
                "messages": [{"role": "user", "content": _SENTINEL}],
            }
        ).encode()
        expected_hash = hashlib.sha256(expected_body).hexdigest()
        self.assertEqual(result.report["requests"][0]["body_sha256"], expected_hash)
        self.assertEqual(result.report["requests"][0]["auth"], "dummy")
        self.assertEqual(result.run["returncode"], 0)
        raw = (self.fixture_root / "evidence" / "p0-sentinel.json").read_bytes()
        # The distinctive prompt sentinel never persists; its request
        # metadata and body hash do.
        self.assertNotIn(_SENTINEL.encode(), raw)
        self.assertIn(expected_hash.encode(), raw)

    def test_p0_child_inherits_soft_rlimits(self) -> None:
        script = self._fake_script(body=_RLIMIT_BODY)
        result = p0.run_p0(
            trusted=self._trusted(script),
            fixture=self.fixture,
            timeout=60.0,
        )
        out = result.run["stdout"]
        # Soft limits lowered to the configured bounds; hard limits (here
        # RLIM_INFINITY) are never reduced.
        self.assertIn("CORE (0, -1)", out)
        self.assertIn("NOFILE (256,", out)
        self.assertIn("FSIZE (16777216,", out)
        self.assertIn("AS (4294967296,", out)
        self.assertIn("CPU (90,", out)  # cpu_seconds = int(timeout) + 30

    def test_p0_fault_injection_no_report_no_evidence(self) -> None:
        script = self._fake_script()
        with self.assertRaisesRegex(ProbeError, "inner reporter failed"):
            p0.run_p0(
                trusted=self._trusted(script),
                fixture=self.fixture,
                timeout=60.0,
                evidence_name="p0-fault",
                fault_injection="assert-dev",
            )
        self.assertFalse((self.fixture_root / "evidence").exists())

    def test_p0_timeout_kills_native_group_no_survivors(self) -> None:
        script = self._fake_script(body=_SH_SLEEP)
        result = p0.run_p0(
            trusted=self._trusted(script),
            fixture=self.fixture,
            timeout=1.0,
            evidence_name="p0-timeout",
        )
        # Returning from run_p0 proves teardown: zero group survivors, no
        # process holding the private mount domain, untouched canaries.
        self.assertTrue(result.run["timed_out"])
        self.assertIsNone(result.run["returncode"])
        self.assertEqual(result.canaries["tcp_contacts"], 0)
        evidence = strict_json.load(self.fixture_root / "evidence" / "p0-timeout.json")
        self.assertTrue(evidence["report"]["run"]["timed_out"])

    def test_p0_parent_watchdog_no_survivors_no_evidence(self) -> None:
        script = self._fake_script(body=_SH_SLEEP)
        with self.assertRaisesRegex(ProbeError, "watchdog"):
            p0.run_p0(
                trusted=self._trusted(script),
                fixture=self.fixture,
                timeout=30.0,
                parent_timeout=1.0,
                evidence_name="p0-watchdog",
            )
        self.assertFalse((self.fixture_root / "evidence").exists())

    def test_p0_private_pty_allocation(self) -> None:
        script = self._fake_script(body=_SH_TTY)
        result = p0.run_p0(
            trusted=self._trusted(script),
            fixture=self.fixture,
            timeout=60.0,
            use_pty=True,
        )
        self.assertEqual(result.run["returncode"], 0)
        self.assertIn("P0-PTY-OK", result.run["stdout"])

    def test_cli_p0_self_test_end_to_end(self) -> None:
        stdout = io.StringIO()
        with contextlib.redirect_stdout(stdout):
            code = probe.probe_cli(
                ["p0-self-test"], self._flags(), [], environ=self.environ
            )
        self.assertEqual(code, 0)
        self.assertIn("p0 self-test:", stdout.getvalue())
        evidence = strict_json.load(
            self.fixture_root / "evidence" / "p0-self-test.json"
        )
        self.assertEqual(evidence["kind"], "p0-run")
        run_evidence = evidence["report"]["run"]
        self.assertEqual(run_evidence["returncode"], 0)
        self.assertGreater(run_evidence["stdout_bytes"], 0)
        self.assertNotIn("stdout", run_evidence)
        self.assertEqual(evidence["keyring"]["payload_keys"], 0)
        raw = (self.fixture_root / "evidence" / "p0-self-test.json").read_bytes()
        self.assertNotIn(b"P0-SELF-TEST-OK", raw)


if __name__ == "__main__":
    unittest.main()
