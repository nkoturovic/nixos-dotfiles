# DeepWork — durable claude-multi session configuration

> **FROZEN 2026-07-22.** The user requested a new agent to rethink the whole
> product from first principles. This record remains evidence only. Do not
> continue its implementation plan. Canonical handoff:
> `docs/claude-multi-rethink-handoff/PROMPT.md`.

## Goal

Replace the proven launch-argv-only agent registry failure with the smallest
reliable design that survives the shared Claude supervisor's upgrade takeover,
while preserving trusted-catalog ownership, concurrent compositions, plain
Claude, legacy sessions, and fail-closed behavior.

User acceptance remains manual. Implementation and local verification must not
contact a real provider or stop the user's active Claude session.

## Confirmed context

- Source repository: `/home/kotur/personal/nixos-dotfiles`, clean at `cf04fce`.
- Current v2 compiles selected agents into `--agents`, appends lead policy by
  argv, writes managed session metadata, then `execve`s Claude.
- Active `kimi-sol` expects six selected `cm-*` variants; a clean long-running
  session initially had them, then lost all six and retained generic `claude`.
- `~/.claude/daemon.log` records the shared supervisor observing the
  `2.1.216 -> 2.1.217` symlink change, self-restarting for upgrade, adopting one
  worker, and refusing one stale respawn. This is the proven failure trigger.
- Environment/model/gateway survived; launch argv did not. Generic `claude`
  inherited Kimi because `Agent(claude)` was not denied.
- Versioned `2.1.216` remains byte-intact at the recorded hash. The configured
  symlink now targets unqualified `2.1.217`; Doctor does not currently share
  launch's binary validation.
- Oracle `ora-6` final recommendation: G0' hygiene plus hard-gated C* for new
  sessions. C* uses a selected-only per-UUID `CLAUDE_CONFIG_DIR` containing
  `agents/`, generated `settings.json`, and generated `CLAUDE.md`. Legacy,
  linked, and v1 sessions remain argv-mode; no transcript migration.
- Rejected unless probes force reconsideration: global mutable agents,
  per-composition config roots, global all-variant registry plus hook, plugins,
  resident supervisor, daemon manipulation, private session-file copying.
- Session-transition/fork defects remain a separate follow-up; C* must not
  claim to solve unverified native fork persistence.

## Hard requirements

1. Trusted catalog remains the only hand-authored agent/policy source.
2. New C* sessions contain only selected variants; generic/unselected agents
   cannot silently substitute.
3. Existing sessions remain resumable in legacy mode without private copying.
4. Plain `claude`, its auth/config/update workflow, and shared daemon remain
   untouched.
5. Concurrent different sessions never rewrite shared active policy.
6. Runtime state uses private paths, atomic writes, explicit cleanup, and
   rollback-safe metadata.
7. Unknown Claude behavior fails closed with an exact recovery command.
8. No activation until packaged validation and Oracle approval.

## Decision gates

- **G0:** G0' trust/health hardening passes focused tests independent of C*.
- **G1:** C* is allowed only if disposable local probes prove agent discovery,
  acceptable trust/onboarding, exact transcript resume, frontmatter parity,
  persistent denies, and background/daemon config inheritance.
- **G2:** Packaged restart/compact/concurrency acceptance passes. If a required
  probe fails, retain G0' plus legacy fail-closed recovery and revise the spec
  through Oracle before adding any hook/global persistence.
- **G3:** Activation preserves the proxy, current package rollback, and plain
  Claude. User performs the first real-session acceptance.

## Phase order and Oracle gates

1. **Blueprint/spec** — write the durable design, unsupported cases, probe
   contract, state lifecycle, security and rollback. Oracle gate: architecture
   and simplicity approval.
2. **Implementation plan** — exact file/test/activation sequence derived from
   approved spec. Oracle gate: no missing dependencies or unsafe ordering.
3. **Foundation and probes** — implement G0', deterministic disposable probe
   harness, run G1, reconcile result. Oracle gate: accept C* decision and probe
   evidence.
4. **C* integration** — implement new-session per-UUID roots or the approved
   fallback, legacy split, cleanup semantics, tests. Oracle gate: correctness,
   migration safety and simplification.
5. **Packaged rollout** — full focused suite, Nix builds, Home Manager switch,
   health checks, docs/wiki, final diff review and commits. Oracle gate: final
   integrated approval before commit/activation completion.

Total planned Oracle reviews: **5**. The Oracle is advisory/review-only; the
orchestrator owns integration and reconciliation.

## Current status

- [x] Existing ignore rules satisfy DeepWork requirements.
- [x] Baseline repository is clean.
- [x] Oracle research and final C* recommendation reconciled.
- [ ] Blueprint/spec drafted and approved.
- [ ] Implementation plan approved.
- [ ] G0' and probes complete.
- [ ] C* or approved fallback complete.
- [ ] Packaged activation, documentation, final review and commits complete.

## Validation evidence

- Blueprint draft: `docs/claude-multi-durable-session-config.md`.
- Local executable evidence: configured symlink resolves to 2.1.217; native
  `claude --version` reports 2.1.217; retained 2.1.216 hash still equals
  `74deca45220b8080ec75ab099bd5a5980e41a2b5879846a008fb115d436de085`;
  2.1.217 hash is
  `2630fc5dc6db61bc03f86b95daf47766e5ed5b61873f7bb7cfea764c5ac5a9ba`.
- Runtime anchor before implementation/activation: Home Manager generation 76
  `/nix/store/xngnqdgicr77dzmfksdbn1jmy2v7h423-home-manager-generation` is
  current; immediate rollback generation 75 is
  `/nix/store/myjl86j988wmb7va0yzhzdfxinj8si66-home-manager-generation`.
  Active package is
  `/nix/store/fxapndpszjxdxz61jm5m12q1ngw014i4-claude-multi-2.0.0`; proxy
  service is active/running at PID 1008913 with that package's ExecStart.
- `claude-multi doctor` still reports Ready despite the configured symlink/native
  contract drift, confirming the Phase-1 Doctor parity defect against the live
  installation.
- Phase-0 local inspection revalidated
  `/home/kotur/.local/share/claude/versions/2.1.217` as an owner-local regular
  executable (`0755`, size 268573680) with full SHA-256
  `2630fc5dc6db61bc03f86b95daf47766e5ed5b61873f7bb7cfea764c5ac5a9ba`;
  `--version` reports `2.1.217 (Claude Code)`.
- Offline `--help` confirms agents, settings, model, effort, explicit session
  ID/resume/fork, background agents, tool policy, worktree, and prompt surfaces.
  Static binary inspection confirms `CLAUDE_CONFIG_DIR`,
  `DISABLE_AUTOUPDATER`, `CLAUDE_CODE_MAX_SUBAGENT_SPAWN_DEPTH`, and
  `CLAUDE_CODE_MAX_CONCURRENT_SUBAGENTS` symbols. Functional behavior remains
  probe-required; static presence is not acceptance evidence.
- Process metadata only (no daemon request/transcript read) shows the shared
  daemon running 2.1.217 while an active managed `kimi-sol` session and its
  spare workers remain on 2.1.216. No process may be stopped or restarted
  during automated Phase-1 work.
- Phase-0 contract promotion keeps the inspected native artifact at 2.1.217
  while model `minimum_tested.claude_code` remains the truthful 2.1.216 floor;
  no provider/model compatibility claim was widened. The closed contract adds
  generic aliases, pending C* capability probes, pending nested-key decisions,
  and a lifecycle evidence ID. Focused catalog/native-contract validation:
  80 tests passed, 1 intentionally skipped real-probe gate.
- Existing state/launch contracts reviewed at `sessions.py`, `launch.py`,
  `compiler.py`, `state.py`, session/native schemas, package/module, and focused
  tests. The blueprint deliberately adds explicit runtime mode rather than
  deriving linked-session behavior from launcher version.
- The blueprint does not atomically replace a transcript-bearing config root on
  composition transition; it reconciles only known managed files and uses a
  manifest as commit marker.

## Oracle blueprint review 1

`ora-6` verdict: **REVISE**. Accepted findings and remediation:

1. P-t now supports two valid transcript-location outcomes; C\* rejects only
   broken exact resume. Configuration-only roots use whole-root replacement and
   safe forget; transcript-bearing roots use managed-file reconciliation and
   retained-root forget.
2. Native probes now require P0 daemon/backend isolation. Disposable HOME alone
   is forbidden because the live daemon socket is uid-scoped. Without a proven
   isolated daemon domain, only client-side reload simulation is allowed.
3. Transition rollback uses pre-read exact old managed bytes, never regenerated
   bytes from a potentially drifted catalog. Crash reconciliation is offered
   only when current drift validation still permits it.
4. G2 now probes project/local settings precedence over generated denies.
5. `CLAUDE_CONFIG_DIR` is explicitly reserved against model lead-env override;
   rollback visibility now states that old launchers skip/error on C\* records
   and cannot clean orphan roots.

Revised blueprint remains at
`docs/claude-multi-durable-session-config.md`; follow-up approval pending.

## Official Claude documentation research

`lib-1` checked official docs/release notes on 2026-07-22 and local 2.1.217
help without a provider request. Accepted findings:

- `CLAUDE_CONFIG_DIR` relocates the entire user Claude home: settings, session
  history/transcripts, plugins, user agents/memory, prompt history, caches and
  Linux/Windows credential files. Project `.claude` and managed policy still
  layer. It is replacement, not fallback/overlay.
- Each config root has a separate supervisor/session roster. P0 must prove the
  pinned runtime's actual socket/domain behavior; official docs support the
  intended isolation but local uid-socket evidence still requires a gate.
- User agents are recursively discovered under `$DIR/agents`; project agents
  have higher precedence than user agents. Exact `cm-*` project collisions must
  therefore fail closed when C\* removes the higher-precedence `--agents`
  overlay.
- Agent files officially support `model`, `effort` (`xhigh`/`max`), tools,
  disallowedTools, background and `isolation: worktree`. Third-party selectors,
  `Agent(claude)` deny, nested-depth variables and some lifecycle behavior remain
  probe-required. `ultracode` is lead-only, not an agent-frontmatter value.
- Permission denies merge before asks/allows, so a user-root deny cannot be
  weakened by project/local allow. P2 still verifies CLI parity and the
  undocumented generic `Agent(claude)` alias.
- `$DIR/CLAUDE.md` is user memory and project instructions concatenate later;
  compaction reinjection of user memory is not separately guaranteed and stays
  probe-required.
- Fresh roots have fresh onboarding/trust/user settings/plugins/MCPs and Linux
  credential state. Gateway env auth avoids model-login duplication, but the
  current statusline/permission/user settings would otherwise disappear unless
  intentionally represented in the generated root.
- Transcripts are officially under `$DIR/projects`; P-t is expected to be the
  transcript-bearing outcome, while the probe remains the pinned-CLI gate.
- 2.1.217 disables nested subagent spawning by default unless the new spawn
  depth control is configured. Current nested-delegation expectations require a
  separate contract decision and probe.

Authoritative references are returned in `lib-1`; the blueprint and plan must
integrate these findings before implementation approval.

Local authoritative snapshot added by the user:
`.agents/wiki/raw/docs/claude-sub-agents.md` (source:
`https://code.claude.com/docs/en/sub-agents`). It confirms:

- `--agents` definitions are current-session-only and are not saved to disk;
- user/project `agents/*.md` trees are recursively discovered and watched;
  creating the first `agents` directory after startup requires a restart, so
  C* must create the complete directory before exec;
- project `.claude/agents/` outranks user-level agents, reinforcing the
  every-launch exact-name collision gate;
- model resolution order is `CLAUDE_CODE_SUBAGENT_MODEL`, per-invocation
  `model`, frontmatter `model`, then inherited model. Therefore C* must
  reserve/unset `CLAUDE_CODE_SUBAGENT_MODEL` and prove or prevent
  per-invocation model substitution before claiming selector immutability;
- file persistence guarantees availability/discovery, not that the lead model
  will always choose to delegate. Lead policy and explicit agent-type dispatch
  remain behavioral controls rather than a platform guarantee.

### Official agent-doc architecture gate

- `exp-3` mapped all six official snapshots against the blueprint/plan and
  found material gaps in workflows, nested spawning, model precedence,
  discovery scopes, gateway wake behavior, worktrees and permissions.
- Original blueprint/plan Oracle `ora-30` returned **REVISE**, explicitly
  keeping C* but requiring eight architecture-section changes.
- The same `ora-30` approved the intended direction (mechanical specialist
  `disallowedTools: Agent`; hard-disabled workflows with `xhigh` fallback) but
  required four corrections before writing:
  1. `disableWorkflows: true` and any incompatible `ultracode` → `xhigh`
     migration for all four lead-capable models ship in the same reviewed
     change set;
  2. specialist Agent denial, `roles.json` contracts and lead/session policy
     wording change atomically, with a typed-error negative probe;
  3. selected-only inventory rejects every discovered agent definition from
     nested project and passthrough `--add-dir` trees, while Doctor verifies
     the managed-settings absence assumption;
  4. disabling agent view ships only if a probe proves background subagents
     remain functional; otherwise retain documented visibility/user-action
     boundaries instead of breaking the default execution mode.
- C* implementation remains blocked until the blueprint and plan are rewritten
  with these corrections and the revised documents return to the same `ora-30`
  session for approval.
- User selected a per-composition workflow toggle with default `native` (on),
  preserving today's actual ultracode behavior while making it explicit.
  Original Oracle `ora-30` returned **REVISE** on the first toggle draft but
  approved its shape subject to five precision clauses: off-mode xhigh is a
  compile-time derived mapping only; native workflow executors are an explicit
  lead-family/acceptEdits/no-worktree exception; optional field absence means
  native and hashes into additive session snapshots; workflow-specific
  model/auth/artifact/permission probes are mandatory; and selected-only plus
  implementer-isolation goals are explicitly narrowed in native mode.
- The first docs writer was cancelled before writing because its global-disable
  policy became obsolete. It is not reusable. A fresh docs-only writer must
  incorporate the default-on toggle plus every prior `ora-30` correction, then
  return the documents to the same `ora-30` session.

## Oracle blueprint gate — final

- `ora-6` approved the architecture in substance after five corrections.
- `ora-8` and `ora-9` closed transcript-outcome and failure-table consistency.
- `ora-6` then reviewed the official-docs integration and required four bounded
  clauses: nested-prompt parity, measurable supervisor cleanup, preference
  refresh/secret/conflict semantics, and functional-vs-cosmetic P3 scope.
- `ora-10` delta-checked those clauses and returned **APPROVE**.

Approved blueprint:
`docs/claude-multi-durable-session-config.md`.

Blueprint status is now final for implementation planning. Any probe result
that violates a hard assumption returns to Oracle before architecture changes.

Implementation-plan draft:
`docs/claude-multi-durable-session-config-plan.md`.

## Oracle implementation-plan gate — final

- `ora-16` verified the five original implementation-plan corrections and
  required one final paired-outcome clause for nested-agent prompt parity.
- `ora-17` verified that clause and returned **APPROVE**.
- The approved plan remains gated: no provider contact, no live-daemon contact,
  and no C* implementation before Phase-1 probe evidence and Oracle approval.

## Whole-product quality boundary

The user explicitly expanded the completion standard from durable-agent state
to `claude-multi` as an end-to-end product. Before final activation/acceptance,
run a holistic review and remediation gate covering:

- startup/no-argument TUI, quick-confirm flow, real PTY and no-controlling-TTY
  behavior, keyboard affordances, accessibility, cancellation and error paths;
- composition selection/editing, trusted-default and `kimi-sol` summaries,
  exact model/effort/role/tool presentation and drift diagnostics;
- fresh/resume/link/transition/forget behavior plus documented fork boundaries;
- binary trust, proxy readiness/service lifecycle, Doctor parity and recovery;
- agent registry/policy/config-root security, namespace probe safety and
  provider/credential isolation;
- packaging, Nix checks, Home Manager activation, gateway restart checkpoint,
  rollback and generated-artifact hygiene;
- README/runbook/acceptance instructions and observable live behavior.

User-visible TUI/interaction quality is designer-owned. Architecture and
integrated risk return to Oracle after implementation. Passing component tests
alone is insufficient; the final gate needs end-to-end evidence.

## Detailed Todo seed

### Specification and planning

- [x] Baseline source/runtime/version/daemon evidence and rollback anchors.
- [x] Draft blueprint and reconcile official Claude documentation.
- [x] Iterate blueprint with Oracle until APPROVE.
- [x] Draft dependency-ordered implementation/verification plan.
- [x] Iterate implementation plan with Oracle until APPROVE.

### G0' foundation

- [x] Reinspect/promote native Claude 2.1.217 evidence without widening
      unverified fork/same-launch claims.
- [x] Fix immutable resolved-path verification and advisory symlink drift.
- [x] Make Doctor and launch share binary verification; report installed/daemon
      informational state.
- [x] Add contract-driven generic-agent denial and updater hygiene.
- [x] Add exact session sentinel and nested-delegation contract parity.
- [x] Add focused unit/golden/failure-order tests.
- G0 independent review `ora-19`: **APPROVE** after remediation. Integrated
  Python discovery: 586 tests passed, 1 intentional real-probe skip. Accepted
  non-blocking residuals: path-based verify/exec TOCTOU, speculative absent
  daemon metadata, per-session prompt retention, and same-uid unusual-file
  edge cases in advisory Doctor metadata.

### Safe capability probes

- [x] Implement P0 live-daemon isolation guard.
- [x] Implement disposable loopback fake-provider/PTTY harness.
- Safe-scaffold review `ora-18`: **APPROVE**, 84 focused tests passed. The
  real pinned-binary path intentionally fails closed because fixture paths do
  not yet prove isolation from the uid-shared daemon domain. G1 remains blocked
  until a separate P0 namespace/UID mechanism is implemented and reviewed.
- P0 research: official Claude docs state a fresh `CLAUDE_CONFIG_DIR` creates a
  separate supervisor instance and `CLAUDE_CODE_DISABLE_AGENT_VIEW=1` disables
  agent view/background supervisor behavior. Pinned-2.1.217 static inspection
  additionally indicates config-root-hashed socket subdomains, but that static
  detail is not treated as a compatibility guarantee.
- Local no-Claude namespace proof succeeded with util-linux 2.41.5:
  user+mount+network+PID namespaces, namespace uid/gid 0 and PID 1, private
  `nosuid,nodev,noexec` tmpfs `/tmp`, loopback-only network with empty routes,
  and no visibility of the host `/tmp/cc-daemon-1000` domain. Oracle design
  review is required before this mechanism can enable the pinned binary.
- `ora-20` accepted the namespace architecture but required credential/session
  masks, representative non-root UID behavior, parent-owned post-exit evidence,
  and experimental host-listener isolation controls. Direct namespace UID 1000
  cannot perform the mount setup on this host; a two-stage no-Claude proof
  succeeded: outer mapped root creates the private namespaces/mounts, then an
  inner user namespace runs as uid/gid 1000 while retaining PID 1, private
  tmpfs `/tmp`, empty routes, and no host daemon path. Revised design `ora-21`
  is the implementation gate.
- Follow-up no-Claude mount proof succeeded with the declared-input model:
  private bounded tmpfs masks `/home`, `/root`, `/run`, and `/tmp`; the exact
  inspected binary inode and repository fixture are bind-mounted read-only or
  declared under private `/run/claude-multi-p0`; inner uid/gid 1000 sees no
  host Claude config, user runtime, system bus, or log socket, while the bound
  binary retains the expected SHA-256 and the network has zero routes.
- `ora-23` identified an unavoidable same-host-kuid keyring limitation without
  seccomp or a distinct host uid. P0 now scopes keyring protection to ambient
  inheritance only, fails closed when host uid-1000 keyrings contain payload
  keys, and records malicious same-uid reattachment/pollution as an accepted
  residual for the hash-pinned trusted client. Real-provider use remains out of
  scope.
- Fresh minimal-device proof also succeeded without Claude: host fixed devices
  are staged before masking, then private tmpfs `/dev` exposes only
  null/zero/full/random/urandom, a fresh devpts+ptmx, private shm and private
  mqueue; no host tty/log/dri/pts devices remain visible. User-namespace
  `mknod` is unavailable, so the fixed-node bind strategy is required.
- Final bounded P0 design review `ora-24`: **APPROVE**. Accepted scope includes
  no inherited ambient keyring payloads plus fail-closed empty-keyring
  preflight; malicious same-host-kuid keyring reattachment remains an explicit
  residual for the hash-pinned trusted client. Implementation may now proceed,
  but pinned Claude execution still waits for unit tests and independent code
  review.
- P0 implementation code-review loop is clean: final outer `ora-34`, inner
  `ora-32`, and integration `ora-33` verdicts are all **APPROVE** after all
  MUST/SHOULD findings and final robustness nits were remediated. Focused local
  verification: 210 tests passed; implementation author full discovery: 651
  passed with 1 intentional real-probe skip.
- Staged P0 runtime acceptance passed on 2026-07-22:
  - fake namespace self-test evidence:
    `/tmp/opencode/cm-p0-selftest.nEUrem/evidence/p0-self-test.json`;
  - contract-pinned 2.1.217 `--version` evidence:
    `/tmp/opencode/cm-p0-version.XnP6H0/evidence/p0-last-run.json`;
  - both runs returned 0 with all 26 namespace/mount/network/IPC/keyring/device
    assertions passing, zero TCP/Unix canary contacts, intact shm/SysV
    canaries, zero key payloads and zero provider requests;
  - pinned run stdout was metadata-only (22 bytes + SHA-256), with no prompt,
    transcript, raw argv, credential or provider content persisted.
- P0 is complete. Accepted residuals remain explicit and bounded to the trusted
  no-provider probe harness: same-host-kuid malicious keyring reattachment,
  overflow supplementary groups, omitted host-wide `RLIMIT_NPROC`, and the
  same-uid verify-to-exec TOCTOU. None are production-launcher mechanisms.
- **Paused 2026-07-22 by user choice.** `fix-3` errored after writing partial
  P0 implementation files `src/claude_multi/p0.py`,
  `src/claude_multi/p0inner.py`, integration in `probe.py`/`dev.py`, and
  `tests/test_p0.py`. Focused evidence is green: 36 P0 tests, 145
  probe/onboarding/hygiene tests, and 622 integrated tests all passed with one
  intentional real-probe skip. No pinned Claude execution occurred.
- Independent implementation review is the blocker. Monolithic `ora-25` and
  bounded `ora-26`/`ora-27`/`ora-28` all failed at the agent runtime with empty
  results and are not reusable. The partial P0 implementation is therefore
  **unreviewed and must not be committed, activated, or used to execute the
  pinned binary**. Resume in a fresh session with a fresh independent code
  reviewer against the approved `ora-24` design; then route all findings to a
  fresh replacement writer. Do not retry the errored sessions.
- [ ] Probe persistent agent discovery and unselected absence.
- [ ] Probe settings denies and project/local precedence.
- [ ] Probe onboarding/auth/functional permissions and preference diagnostics.
- [ ] Probe transcript location and exact resume.
- [ ] Probe selector/effort/tools/worktree parity with negative controls.
- [ ] Probe lead effort survival across takeover/reload; persist a
      composition-owned native `effortLevel` only if required by evidence.
- [ ] Probe both nested-agent depth/concurrency keys with positive and negative
      controls, including depth-0 refusal and configured-depth success.
- [ ] Probe nested/background inheritance and supervisor cleanup.
- [ ] Probe CLAUDE.md lifecycle and project-agent collisions.
- [ ] Record evidence and obtain Oracle G1 decision.

### C\* implementation (only after G1)

- [ ] Add explicit backward-compatible runtime-mode record fields.
- [ ] Add pure selected-agent/settings/lead/manifest generator.
- [ ] Add closed preference snapshot/secret scan/conflict ownership.
- [ ] Add project-agent frontmatter collision scanner.
- [ ] Run the project-agent `cm-*` collision scanner on fresh launch, exact
      resume, and composition transition.
- [ ] Add private per-UUID root creation and known-file reconciliation.
- [ ] Add fresh/resume/transition rollback and crash recovery.
- [ ] Preserve legacy/link argv mode and safe forget/orphan semantics.
- [ ] Cut C\* argv over only after file/lead/settings parity evidence.
- [ ] Add security, state, compatibility, concurrency and leakage tests.
- [ ] Obtain Oracle C\* review and remediate until APPROVE.

### Packaging and rollout

- [ ] Run focused/full Python tests and diff/artifact scans.
- [ ] Run package, flake check target and activation-package builds.
- [ ] Run packaged lifecycle probes under P0 safety.
- [ ] Capture generations/package/service and rollback state.
- [ ] Obtain final Oracle integrated APPROVE.
- [ ] Inspect final source diffs/logs/secrets and commit source so flake
      evaluation can see the verified implementation.
- [ ] Checkpoint live managed sessions, then activate once through Home Manager;
      expect a brief gateway interruption when `cli-proxy-api` restarts.
- [ ] Verify proxy/Doctor/compositions and preserve the immediate rollback.
- [ ] Update README/runbooks/blueprint/wiki and acceptance instructions, then
      commit documentation/wiki changes separately.
- [ ] Hand user exact fresh-session/resume/registry acceptance procedure.
- [ ] Re-orient on deferred native fork/session-transition work after acceptance.

## Rollback

- Source rollback: prior commit `cf04fce`.
- Runtime rollback: Home Manager generation 76 at
  `/nix/store/xngnqdgicr77dzmfksdbn1jmy2v7h423-home-manager-generation` remains
  active; immediate rollback is generation 75 at
  `/nix/store/myjl86j988wmb7va0yzhzdfxinj8si66-home-manager-generation`.
- C* records/config roots must be additive and must not delete legacy/native
  transcripts automatically.
